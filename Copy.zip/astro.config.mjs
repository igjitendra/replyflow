import { defineConfig } from 'astro/config';
import tailwind from '@astrojs/tailwind';

// https://astro.build/config
export default defineConfig({
  site: 'https://replyflow.procsctools.in',
  integrations: [
    tailwind({
      applyBaseStyles: false,
    }),
  ],
  redirects: {
    '/template/retail-product-ready-for-pickup-service-friendly': '/template/retail-exchange-product-ready-pickup-friendly',
  },
});

