---
id: retail-loyalty-points-expiry-friendly
title: "Loyalty Points Expiry Reminder — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: loyalty-points-expiry
objective: retention
tone: friendly
language: hinglish
best_time: "10:00-19:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-loyalty-points-expiry-friendly.webp"
meta_title: "Loyalty Points Expiry Reminder | ReplyFlow"
meta_description: "Urgent loyalty points expiry WhatsApp template for customer retention."
preview_snippet: "Warning {{customer_name}}! Aapke {{expiring_points}} reward points expire hone wale hain on {{expiry_date}}..."
context_section:
  when_to_use: "Send 3 to 7 days before earned reward points expire."
  target_audience: "Reward program members with unredeemed points."
  customization_tip: "Add direct link to redeem points on next checkout."
variables:
  - customer_name
  - shop_name
  - expiring_points
  - expiry_date
  - redeem_link
tags:
  - points-expiry
  - loyalty-reminder
  - redeem-points
buttons:
  - type: url
    text: "🎁 Redeem Points Before Expiry"
variations:
  - title: "Hinglish Version"
    text: "Warning {{customer_name}}! ⏰\n\nAapke *{{shop_name}}* account mein *{{expiring_points}} reward points* expire hone wale hain on *{{expiry_date}}*!\n\nPoints waste hone se pehle discount mein convert karein:\nRedeem Link: {{redeem_link}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "सावधान {{customer_name}} जी! आपके {{expiring_points}} रिवॉर्ड पॉइंट्स {{expiry_date}} को एक्सपायर हो रहे हैं। रिडीम करें: {{redeem_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Urgent {{customer_name}}! Your *{{expiring_points}} reward points* at *{{shop_name}}* will expire on *{{expiry_date}}*. Redeem now: {{redeem_link}}"
    tone: "friendly"
    language: "en"
---
Warning {{customer_name}}! ⏰

Aapke *{{shop_name}}* account mein *{{expiring_points}} reward points* expire hone wale hain on *{{expiry_date}}*!

Points waste hone se pehle discount mein convert karein:
Redeem Link: {{redeem_link}}
