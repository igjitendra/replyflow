---
id: retail-delivery-rescheduled-friendly
title: "Delivery Date Rescheduled Confirmation — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: delivery-rescheduled
objective: support
tone: friendly
language: hinglish
best_time: "09:00-21:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-delivery-rescheduled-friendly.webp"
meta_title: "Delivery Date Rescheduled Confirmation... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping delivery rescheduled. Copy, customize variables, and double your reply conversion rates on Repl..."
preview_snippet: "Hi {{customer_name}}! 🗓️ Delivery Rescheduled for Order {{order_id}}! New Delivery Date: {{date}} @ {{time}} Naye..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant delivery rescheduled touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - order_id
  - date
  - time
tags:
  - delivery-rescheduled
  - new-time-slot
  - reschedule-confirmed
buttons:
  - type: reply
    text: "✅ Confirm New Slot"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! 🗓️ Delivery Rescheduled for Order #{{order_id}}!\n\nNew Delivery Date: {{date}} @ {{time}}\n\nNaye time slot par parcel deliver kar diya jayega!"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! 🗓️ आर्डर #{{order_id}} की डिलीवरी नई तारीख ({{date}}, समय: {{time}}) के लिए रीशेड्यूल हो गई है।"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! 🗓️ Delivery for Order #{{order_id}} has been rescheduled to {{date}} @ {{time}}."
    tone: "professional"
    language: "en"
---
Hi {{customer_name}}! 🗓️ Delivery Rescheduled for Order #{{order_id}}!

New Delivery Date: {{date}} @ {{time}}

Naye time slot par parcel deliver kar diya jayega!
