---
id: retail-cancellation-confirmed-friendly
title: "Order Cancellation & Refund Processed — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: cancellation-confirmed
objective: support
tone: friendly
language: hinglish
best_time: "09:00-21:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-cancellation-confirmed-friendly.webp"
meta_title: "Order Cancellation & Refund Processed (Whatsapp) | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping cancellation confirmed. Copy, customize variables, and double your reply conversion rates on Re..."
preview_snippet: "Hi {{customer_name}}! ❌ Order {{order_id}} Cancelled & Refund Initiated! Refund Amount ₹{{amount}} aapke original payment..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant cancellation confirmed touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - order_id
  - amount
tags:
  - cancellation-confirmed
  - refund-processed
  - order-cancelled
buttons:
  - type: reply
    text: "💰 Check Refund Status"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! ❌ Order #{{order_id}} Cancelled & Refund Initiated!\n\nRefund Amount ₹{{amount}} aapke original payment source me 24-48 hours me credit ho jayega."
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! ❌ आर्डर #{{order_id}} कैंसिल हो गया है और ₹{{amount}} का रिफंड भेज दिया गया है।"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! ❌ Order #{{order_id}} has been cancelled. Refund of ₹{{amount}} initiated."
    tone: "professional"
    language: "en"
---
Hi {{customer_name}}! ❌ Order #{{order_id}} Cancelled & Refund Initiated!

Refund Amount ₹{{amount}} aapke original payment source me 24-48 hours me credit ho jayega.
