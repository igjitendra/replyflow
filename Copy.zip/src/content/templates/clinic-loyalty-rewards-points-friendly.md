---
id: clinic-loyalty-rewards-points-friendly
title: "Patient Wellness Loyalty Points & Free Health Checkup Voucher — {{clinic_name}}"
industry: clinic
channel: whatsapp
purpose: loyalty-program-welcome
objective: retention
tone: friendly
language: hinglish
best_time: "10:00-18:00"
whatsapp_approved: true
thumbnail: "/images/templates/clinic-loyalty-rewards-points-friendly.webp"
meta_title: "Patient Wellness Loyalty Points & Free Health Checkup Voucher | ReplyFlow"
meta_description: "WhatsApp patient loyalty rewards template: Earn wellness points on clinic consultations and claim free health checkups."
preview_snippet: "Namaste {{patient_name}} ji! Congratulations, {{clinic_name}} Health Club par aapke *{{earned_points}}* Wellness Points credit ho gaye hain..."
context_section:
  when_to_use: "Send after patient completes a consultation or health checkup to credit loyalty points."
  target_audience: "Clinic patients and health-conscious families."
  customization_tip: "Highlight free lab test or consultation voucher reward."
variables:
  - patient_name
  - clinic_name
  - earned_points
  - total_points
  - next_reward
  - rewards_link
tags:
  - clinic-loyalty
  - patient-rewards
  - wellness-points
  - health-checkup
buttons:
  - type: url
    text: "🩺 View Wellness Points & Rewards"
  - type: reply
    text: "📅 Book Free Follow-up Visit"
variations:
  - title: "Hinglish Version"
    text: "Namaste {{patient_name}} ji! 🩺✨\n\n*{{clinic_name}}* Wellness Club par aapke *{{earned_points}}* Health Points credit ho gaye hain!\n\nTotal Points Balance: *{{total_points}} Points*\nNext Free Reward: *{{next_reward}}*\n\nWellness Rewards Portal: {{rewards_link}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! *{{clinic_name}}* हेल्थ क्लब पर आपके {{earned_points}} पॉइंट्स जुड़ गए हैं। कुल बैलेंस: {{total_points}}। रिवार्ड्स देखें: {{rewards_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{patient_name}}! You earned *{{earned_points}}* Wellness Points at *{{clinic_name}}*. Total Balance: *{{total_points}} Points*. Claim free checkup rewards: {{rewards_link}}"
    tone: "friendly"
    language: "en"
---
Namaste {{patient_name}} ji! 🩺✨

*{{clinic_name}}* Wellness Club par aapke *{{earned_points}}* Health Points credit ho gaye hain!

Total Points Balance: *{{total_points}} Points*
Next Free Reward: *{{next_reward}}*

Wellness Rewards Portal: {{rewards_link}}
