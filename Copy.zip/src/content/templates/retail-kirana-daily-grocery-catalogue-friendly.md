---
id: retail-kirana-daily-grocery-catalogue-friendly
title: "Daily Kirana & Grocery Price List Catalogue — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: daily-grocery-catalogue
objective: lead-generation
tone: friendly
language: hinglish
best_time: "08:00-12:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-kirana-daily-grocery-catalogue-friendly.webp"
meta_title: "Daily Kirana & Grocery Price List Catalogue | ReplyFlow"
meta_description: "WhatsApp message template for Kirana & Grocery shop daily price updates and catalog sharing."
preview_snippet: "Namaste {{customer_name}}! Aaj ki fresh sabzi, atta, tel aur daily grocery ki rate list *{{shop_name}}* par tayyar hai..."
context_section:
  when_to_use: "Send early morning to neighborhood customers for daily Kirana orders."
  target_audience: "Local household grocery buyers."
  customization_tip: "Attach PDF catalog or WhatsApp Store link for 1-click ordering."
variables:
  - customer_name
  - shop_name
  - today_specials
  - free_delivery_min
  - catalog_link
tags:
  - kirana
  - grocery
  - daily-ration
  - price-list
buttons:
  - type: url
    text: "🛒 View Today's Grocery Rate List"
  - type: reply
    text: "📝 Send Order List on WhatsApp"
variations:
  - title: "Hinglish Version"
    text: "Namaste {{customer_name}}! Aaj ki fresh sabzi, atta, tel aur daily kirana ki rate list *{{shop_name}}* par ready hai!\n\n🔥 Today's Offers: {{today_specials}}\n🚚 Free Home Delivery above ₹{{free_delivery_min}}!\n\nOrder List Send Karein Ya Rate List Dekhein: {{catalog_link}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! आज का ताज़ा राशन और किराना रेट लिस्ट *{{shop_name}}* पर तैयार है। फ्री होम डिलीवरी ₹{{free_delivery_min}} के ऊपर: {{catalog_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Good morning {{customer_name}}! Fresh daily groceries, vegetables, and staples are ready at *{{shop_name}}*. Free delivery on orders above ₹{{free_delivery_min}}: {{catalog_link}}"
    tone: "friendly"
    language: "en"
---
Namaste {{customer_name}}! Aaj ki fresh sabzi, atta, tel aur daily kirana ki rate list *{{shop_name}}* par ready hai!

🔥 Today's Offers: {{today_specials}}
🚚 Free Home Delivery above ₹{{free_delivery_min}}!

Order List Send Karein Ya Rate List Dekhein: {{catalog_link}}
