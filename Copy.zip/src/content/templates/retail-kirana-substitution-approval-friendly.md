---
id: retail-kirana-substitution-approval-friendly
title: "Out-of-Stock Item Substitution Approval — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: substitution-approval
objective: support
tone: friendly
language: hinglish
best_time: "08:00-20:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-kirana-substitution-approval-friendly.webp"
meta_title: "Out-of-Stock Item Substitution Approval | ReplyFlow"
meta_description: "WhatsApp template asking customer approval for alternative brand/size when ordered grocery item is out of stock."
preview_snippet: "Hi {{customer_name}}, aapke order ka item {{requested_item}} filhaal stock out hai. Alternate brand {{substitute_item}} bhej dein?..."
context_section:
  when_to_use: "Send when an ordered grocery item is unavailable and an alternative is suggested."
  target_audience: "Online or WhatsApp grocery order customers."
  customization_tip: "Provide 1-click YES/NO reply buttons."
variables:
  - customer_name
  - shop_name
  - requested_item
  - substitute_item
  - price_difference
tags:
  - item-substitution
  - stock-out
  - customer-approval
buttons:
  - type: reply
    text: "✅ Haan Bhej Do"
  - type: reply
    text: "❌ Cancel This Item"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}, *{{shop_name}}* se update:\n\nAapke order mein *{{requested_item}}* out of stock hai. Iski jagah same quality *{{substitute_item}}* (Price diff: {{price_difference}}) pack kar dein?\n\nKripya reply karke confirm karein!"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी, आपके आर्डर में *{{requested_item}}* उपलब्ध नहीं है। क्या इसकी जगह *{{substitute_item}}* भेज दें? कृपया रिप्लाई कर बताएं।"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}, *{{requested_item}}* is currently out of stock at *{{shop_name}}*. May we substitute it with *{{substitute_item}}* (Price difference: {{price_difference}})? Please reply to confirm."
    tone: "friendly"
    language: "en"
---
Hi {{customer_name}}, *{{shop_name}}* se update:

Aapke order mein *{{requested_item}}* out of stock hai. Iski jagah same quality *{{substitute_item}}* (Price diff: {{price_difference}}) pack kar dein?

Kripya reply karke confirm karein!
