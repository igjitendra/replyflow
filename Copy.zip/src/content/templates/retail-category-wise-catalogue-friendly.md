---
id: retail-category-wise-catalogue-friendly
title: "{{category_name}} Product Catalogue — Browse Items at {{shop_name}}"
industry: retail
channel: whatsapp
purpose: category-wise-catalogue
objective: lead-generation
tone: friendly
language: hinglish
best_time: "10:00-20:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-category-wise-catalogue-friendly.webp"
meta_title: "Product Catalogue — Browse Items at (Whatsapp) | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping category wise catalogue. Copy, customize variables, and double your reply conversion rates on R..."
preview_snippet: "Hi {{customer_name}}! 📦 {{shop_name}} ka latest {{category_name}} catalogue ready hai! Category: {{category_name}} Starting Price: ₹{{starting_price}}..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant category wise catalogue touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - shop_name
  - category_name
  - starting_price
  - order_link
tags:
  - category-catalogue
  - category-list
  - retail-category
buttons:
  - type: url
    text: "🛍️ View Category Catalogue"
  - type: reply
    text: "⚡ Ask Stock Status"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! 📦 *{{shop_name}}* ka latest *{{category_name}}* catalogue ready hai!\n\nCategory: {{category_name}}\nStarting Price: ₹{{starting_price}}\nCatalogue Link: {{order_link}}\n\nProduct order karne ke liye screenshot ya product code bhein!"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! 📦 हमारा *{{category_name}}* प्रोडक्ट कैटलॉग आ गया है!\n\nकेटेगरी: {{category_name}}\nशुरुआती कीमत: ₹{{starting_price}}\nकैटलॉग देखें: {{order_link}}\n\nप्रोडक्ट आर्डर करने के लिए उसका स्क्रीनशॉट या कोड भेजें।"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! 📦 Our latest *{{category_name}}* catalogue is live at *{{shop_name}}*!\n\nCategory: {{category_name}}\nStarting Price: ₹{{starting_price}}\nBrowse Catalogue: {{order_link}}\n\nSend a screenshot or product code to place your order!"
    tone: "professional"
    language: "en"
---
Hi {{customer_name}}! 📦 *{{shop_name}}* ka latest *{{category_name}}* catalogue ready hai!

Category: {{category_name}}
Starting Price: ₹{{starting_price}}
Catalogue Link: {{order_link}}

Product order karne ke liye screenshot ya product code bhein!
