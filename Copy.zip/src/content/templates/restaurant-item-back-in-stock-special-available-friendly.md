---
id: restaurant-item-back-in-stock-special-available-friendly
title: "Out-of-Stock Dish Back-in-Kitchen Alert"
industry: restaurant
channel: whatsapp
purpose: item-back-in-stock-alert
objective: retention
tone: friendly
language: hinglish
best_time: "11:30-20:30"
whatsapp_approved: true
thumbnail: "/images/templates/restaurant-item-back-in-stock-special-available-friendly.webp"
meta_title: "Out-of-Stock Dish Back-in-Kitchen Alert... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Restaurant & Cafe item back in stock alert. Copy, customize variables, and double your reply conversion rates on ..."
preview_snippet: "Hi {{customer_name}}! 🎉 GOOD NEWS! Aapka favourite bestseller dish {{item_name}} at {{restaurant_name}} ab dobara kitchen..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Restaurant & Cafe team needs to execute an instant item back in stock alert touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Restaurant & Cafe managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - item_name
  - restaurant_name
  - order_link
tags:
  - back-in-stock
  - food-alert
  - stock-update
  - popular-dish
  - customer-retention
buttons:
  - type: reply
    text: "🍲 Order Back-in-Stock Dish"
  - type: url
    text: "📲 Order Online Direct"
  - type: phone
    text: "📞 Call Kitchen Helpline"
variations:
  - title: "Hinglish Version"
    text: |
      Hi {{customer_name}}! 🎉 GOOD NEWS!
      
      Aapka favourite bestseller dish *{{item_name}}* at *{{restaurant_name}}* ab dobara kitchen mein freshly available hai!
      
      🔥 Fresh batches prepared & ready to serve!
      
      Last time yeh stock out ho gaya tha, isliye abhi niche link se apna order secure karein: {{order_link}}
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: |
      नमस्ते {{customer_name}} जी! 🎉 खुशखबरी!
      
      आपका पसंदीदा व्यंजन *{{item_name}}* (*{{restaurant_name}}*) अब दोबारा हमारी रसोई में उपलब्ध है!
      
      🔥 ताज़ा बैच तैयार है!
      
      पिछली बार यह डिश बहुत जल्दी समाप्त हो गई थी, इसलिए बिना देर किए नीचे लिंक पर क्लिक करके अपना ऑर्डर दें: {{order_link}}
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: |
      Dear {{customer_name}}, great news for your palate! 🎉
      
      Your favorite signature dish, *{{item_name}}* at *{{restaurant_name}}*, is BACK IN KITCHEN & ready for ordering!
      
      🔥 Freshly prepared gourmet batch available now.
      
      Hurry before it sells out again! Tap below to place your priority order: {{order_link}}
    tone: "friendly"
    language: "en"
related:
  - restaurant-todays-special-chef-recommendation-friendly
  - restaurant-digital-pdf-qr-menu-sharing-friendly
---
Hi {{customer_name}}! 🎉 GOOD NEWS!

Aapka favourite bestseller dish **{{item_name}}** at **{{restaurant_name}}** ab dobara kitchen mein freshly available hai!

🔥 Fresh batches prepared & ready to serve!

Last time yeh stock out ho gaya tha, isliye abhi niche link se apna order secure karein: {{order_link}}
