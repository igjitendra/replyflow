---
id: retail-comeback-discount-friendly
title: "Special Comeback Discount Code — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: comeback-discount
objective: retention
tone: friendly
language: hinglish
best_time: "10:00-19:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-comeback-discount-friendly.webp"
meta_title: "Special Comeback Discount Code | ReplyFlow"
meta_description: "Ready-to-use WhatsApp template to re-engage lapsed customers with an exclusive comeback coupon code."
preview_snippet: "Hi {{customer_name}}, aapke liye special comeback discount ready hai! Code {{coupon_code}} se paaye {{discount}} OFF..."
context_section:
  when_to_use: "Use when sending win-back promotion campaigns to previous buyers."
  target_audience: "Past customers who haven't ordered recently."
  customization_tip: "Highlight savings percentage and add direct link."
variables:
  - customer_name
  - shop_name
  - discount
  - coupon_code
  - expiry_date
  - shop_link
tags:
  - comeback-discount
  - win-back
  - coupon-code
buttons:
  - type: url
    text: "🎉 Claim Discount Now"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}, aapke liye special comeback discount ready hai at *{{shop_name}}*!\n\nUse Code: *{{coupon_code}}* and get {{discount}} OFF on your next order!\nValid till: {{expiry_date}}\n\nShop Now: {{shop_link}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! आपके लिए खास कमबैक डिस्काउंट उपलब्ध है!\n\nकोड {{coupon_code}} का उपयोग करें और पाएं {{discount}} की छूट!\nअंतिम तिथि: {{expiry_date}}\n\nऑर्डर करें: {{shop_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}, we have a special comeback discount waiting for you at *{{shop_name}}*!\n\nApply promo code *{{coupon_code}}* for {{discount}} OFF.\nValid until: {{expiry_date}}\n\nShop Now: {{shop_link}}"
    tone: "friendly"
    language: "en"
---
Hi {{customer_name}}, aapke liye special comeback discount ready hai at *{{shop_name}}*!

Use Code: *{{coupon_code}}* and get {{discount}} OFF on your next order!
Valid till: {{expiry_date}}

Shop Now: {{shop_link}}
