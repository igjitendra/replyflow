---
id: restaurant-inactive-foodie-winback-voucher-friendly
title: "Inactive Customer Win-Back ₹150 Voucher"
industry: restaurant
channel: whatsapp
purpose: inactive-foodie-winback-voucher
objective: retention
tone: friendly
language: hinglish
best_time: "12:00-21:00"
whatsapp_approved: true
thumbnail: "/images/templates/restaurant-inactive-foodie-winback-voucher-friendly.webp"
meta_title: "Inactive Customer Win-Back ₹150 Voucher... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Restaurant & Cafe inactive foodie winback voucher. Copy, customize variables, and double your reply conversion ra..."
preview_snippet: "We miss you {{customer_name}} ji! 🍕❤️ Kafi din ho gaye aapko {{restaurant_name}} se khana order..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Restaurant & Cafe team needs to execute an instant inactive foodie winback voucher touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Restaurant & Cafe managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - restaurant_name
  - discount_amount
  - coupon_code
  - valid_date
tags:
  - winback-voucher
  - inactive-customer
  - food-discount
  - customer-retention
  - promo-coupon
buttons:
  - type: reply
    text: "🎁 Claim ₹150 Off Voucher"
  - type: url
    text: "📖 View Menu & Order Online"
  - type: phone
    text: "📞 Call Kitchen Helpline"
variations:
  - title: "Hinglish Version"
    text: |
      We miss you {{customer_name}} ji! 🍕❤️
      
      Kafi din ho gaye aapko *{{restaurant_name}}* se khana order kiye huye! Humne aapke favourite dishes miss kiye.
      
      🎁 *Exclusive Welcome-Back Gift:* Get Flat *₹{{discount_amount}} OFF* on your next order!
      🎟️ *Use Coupon:* *{{coupon_code}}* (Valid till {{valid_date}})
      
      Aaj hi apne favourite food order par discount claim karne ke liye niche button click karein!
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: |
      हमें आपकी याद आ रही है {{customer_name}} जी! 🍕❤️
      
      काफी समय हो गया आपको *{{restaurant_name}}* से पसंदीदा भोजन ऑर्डर किए हुए!
      
      🎁 *खास वेलकम-बैक वाउचर:* अपने अगले ऑर्डर पर पाएं सीधी *₹{{discount_amount}} की छूट*!
      🎟️ *कूपन कोड:* *{{coupon_code}}* (वैलिडिटी: {{valid_date}})
      
      आज ही स्वादिष्ट भोजन ऑर्डर करने के लिए नीचे बटन पर क्लिक करें।
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: |
      We miss having you around, {{customer_name}}! 🍕❤️
      
      It's been a while since your last delicious meal from *{{restaurant_name}}*! We'd love to serve you again.
      
      🎁 *Special Welcome-Back Voucher:* Enjoy Flat *₹{{discount_amount}} SAVINGS* on your next dining or delivery order!
      🎟️ *Promo Code:* *{{coupon_code}}* (Valid until {{valid_date}})
      
      Tap below to claim your gift voucher and browse our latest menu.
    tone: "friendly"
    language: "en"
related:
  - restaurant-post-dining-google-review-friendly
  - restaurant-digital-pdf-qr-menu-sharing-friendly
---
We miss you {{customer_name}} ji! 🍕❤️

Kafi din ho gaye aapko **{{restaurant_name}}** se khana order kiye huye! Humne aapke favourite dishes miss kiye.

🎁 **Exclusive Welcome-Back Gift:** Get Flat **₹{{discount_amount}} OFF** on your next order!
🎟️ **Use Coupon:** **{{coupon_code}}** (Valid till {{valid_date}})

Aaj hi apne favourite food order par discount claim karne ke liye niche button click karein!
