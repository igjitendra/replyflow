---
id: retail-karwa-chauth-collection-friendly
title: "Karwa Chauth Pooja Thali & Solah Shringar Hampers — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: karwa-chauth-hampers
objective: lead-generation
tone: friendly
language: hinglish
best_time: "09:00-20:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-karwa-chauth-collection-friendly.webp"
meta_title: "Karwa Chauth Pooja Thali & Solah Shringar Hampe... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping karwa chauth hampers. Copy, customize variables, and double your reply conversion rates on Repl..."
preview_snippet: "🌙 {{shop_name}} Karwa Chauth Festive Collection! Sargi, Ethnic Wear & Gift combos par payein {{discount}}..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant karwa chauth hampers touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - shop_name
  - discount
  - date
  - order_link
  - shop_address
tags:
  - karwa-chauth
  - sargi-gifts
  - ethnic-collection
buttons:
  - type: url
    text: "🌙 Shop Karwa Chauth Special"
variations:
  - title: "Hinglish Version"
    text: "🌙 *{{shop_name}}* Karwa Chauth Festive Collection!\n\nSargi, Ethnic Wear & Gift combos par payein {{discount}} OFF!\n\nOffer valid till: {{date}}\nCatalogue: {{order_link}}\nStore Location: {{shop_address}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "🌙 *{{shop_name}}* करवा चौथ स्पेशल कलेक्शन! सरगी व ब्यूटी प्रोडक्ट्स पर पाएं {{discount}} की विशेष छूट। कैटलॉग: {{order_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "🌙 Karwa Chauth Special Collection at *{{shop_name}}*! Enjoy UPTO {{discount}} OFF till {{date}}. Catalogue: {{order_link}}"
    tone: "professional"
    language: "en"
---
🌙 *{{shop_name}}* Karwa Chauth Festive Collection!

Sargi, Ethnic Wear & Gift combos par payein {{discount}} OFF!

Offer valid till: {{date}}
Catalogue: {{order_link}}
Store Location: {{shop_address}}
