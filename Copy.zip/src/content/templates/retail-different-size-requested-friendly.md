---
id: retail-different-size-requested-friendly
title: "Size Fit Adjustment & Exchange Guidance — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: size-fit-exchange
objective: support
tone: friendly
language: hinglish
best_time: "09:00-20:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-different-size-requested-friendly.webp"
meta_title: "Size Fit Adjustment & Exchange Guidance... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping size fit exchange. Copy, customize variables, and double your reply conversion rates on ReplyFlow."
preview_snippet: "Hello {{customer_name}}! 📐 We received your request to exchange {{product_name}} for size {{requested_size}}. Size Availability:..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant size fit exchange touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - product_name
  - requested_size
  - stock_status
  - size_chart_link
  - exchange_date
tags:
  - size-exchange-request
  - different-size
  - size-replacement
buttons:
  - type: reply
    text: "📏 Confirm New Size {{variant}}"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! Order ID *{{order_id}}* ({{product_name}}) ke liye naya size *{{variant}}* request receive ho gaya hai.\n\nReplacement size process ho raha hai."
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! Order ID {{order_id}} के लिए अलग साइज {{variant}} का अनुरोध प्राप्त हो गया है।"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! Size change request to {{variant}} for Order #{{order_id}} ({{product_name}}) is registered and processing."
    tone: "professional"
    language: "en"
---
Hello {{customer_name}}! 📐

We received your request to exchange {{product_name}} for size {{requested_size}}.

Size Availability: {{stock_status}}
Fit Guide Link: {{size_chart_link}}

Our courier will pick up the current size during exchange delivery on {{exchange_date}}.
