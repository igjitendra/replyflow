---
id: real-estate-rental-tenant-verification-professional-en
title: "Rental Tenant Agreement & Police Verification Notice"
industry: real-estate
channel: whatsapp
purpose: rental-tenant-verification
objective: support
tone: professional
language: en
best_time: "10:00-16:00"
whatsapp_approved: true
thumbnail: "/images/templates/real-estate-rental-tenant-verification-professional-en.webp"
meta_title: "Rental Tenant Agreement & Police Verification N... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Real Estate rental tenant verification. Copy, customize variables, and double your reply conversion rates on Repl..."
preview_snippet: "Dear {{tenant_name}}, Welcome to your new home at {{property_address}}! 🔑🏡 To complete your tenancy onboarding,..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Real Estate team needs to execute an instant rental tenant verification touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Real Estate managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - tenant_name
  - property_address
  - rent_amount
tags:
  - rental
  - tenant
  - verification
  - agreement
buttons:
  - type: reply
    text: "📄 Upload KYC Documents"
  - type: phone
    text: "📞 Contact Rental Desk"
related:
  - real-estate-booking-confirmation-professional-en
---
Dear {{tenant_name}},

Welcome to your new home at {{property_address}}! 🔑🏡

To complete your tenancy onboarding, kindly submit the following documents for Rent Agreement drafting & Police Verification:

1️⃣ Aadhar Card Copy (Tenant + Co-tenants)
2️⃣ Permanent Address Proof & Company ID
3️⃣ Passport Size Photographs (2 Nos.)
4️⃣ Monthly Rent Agreed: {{rent_amount}}

Please send scanned PDFs or clear images here by tomorrow so we can finalize the 11-month lease agreement.
