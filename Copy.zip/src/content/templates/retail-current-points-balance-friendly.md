---
id: retail-current-points-balance-friendly
title: "Wallet Reward Points Balance Summary — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: current-points-balance
objective: retention
tone: friendly
language: hinglish
best_time: "09:00-20:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-current-points-balance-friendly.webp"
meta_title: "Wallet Reward Points Balance Summary (Whatsapp) | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping current points balance. Copy, customize variables, and double your reply conversion rates on Re..."
preview_snippet: "Hi {{customer_name}}! {{shop_name}} Loyalty Wallet Balance: Available Points: {{total_points}} Points In points ko next billing..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant current points balance touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - shop_name
  - total_points
  - order_link
tags:
  - points-balance
  - wallet-summary
  - loyalty-points
buttons:
  - type: url
    text: "💰 Redeem Points for Vouchers"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! *{{shop_name}}* Loyalty Wallet Balance:\n\nAvailable Points: *{{total_points}}* Points\n\nIn points ko next billing par redeem karein: {{order_link}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! *{{shop_name}}* वॉलेट पॉइंट्स समरी: उपलब्ध पॉइंट्स: {{total_points}}। रिडीम करें: {{order_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! Your current *{{shop_name}}* Reward Points Balance: {{total_points}} Points. Redeem on your next visit: {{order_link}}"
    tone: "professional"
    language: "en"
---
Hi {{customer_name}}! *{{shop_name}}* Loyalty Wallet Balance:

Available Points: *{{total_points}}* Points

In points ko next billing par redeem karein: {{order_link}}
