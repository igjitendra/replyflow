---
id: retail-60-day-inactive-customer-friendly
title: "60-Day Inactive Customer High-Incentive Win-Back — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: 60-day-inactive-customer
objective: retention
tone: friendly
language: hinglish
best_time: "12:00-19:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-60-day-inactive-customer-friendly.webp"
meta_title: "60-Day Inactive Customer High-Incentive Win-Back | ReplyFlow"
meta_description: "WhatsApp message template for 60-day dormant retail customers offering high value cashback and store credit."
preview_snippet: "Hi {{customer_name}}! 60 din beet gaye, hum aapko miss kar rahe hain at {{shop_name}}! Aapke liye VIP comeback offer..."
context_section:
  when_to_use: "Use when retail customers haven't purchased for 60 days to prevent permanent churn."
  target_audience: "Dormant customers needing high monetary motivation to return."
  customization_tip: "Pair with a free gift or bonus store credit points for maximum response."
variables:
  - customer_name
  - shop_name
  - offer_details
  - coupon_code
  - expiry_date
  - shop_link
tags:
  - 60-day-inactive
  - churn-prevention
  - win-back-campaign
  - special-perk
buttons:
  - type: url
    text: "🎁 Claim 60-Day Special Perk"
  - type: reply
    text: "🔄 Request Call Back"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! 60 din beet gaye, hum aapko miss kar rahe hain at *{{shop_name}}*!\n\nAapke account mein exclusive VIP comeback perk add kar diya gaya hai:\n🔥 {{offer_details}}\n\nUse Code: *{{coupon_code}}*\nValid till: {{expiry_date}}\n\nClaim Now: {{shop_link}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! 60 दिन बीत गए, हम आपको बहुत याद कर रहे हैं!\n\nआपके अकाउंट में विशेष कमबैक ऑफर ऐड किया गया है:\n🔥 {{offer_details}}\n\nकोड: {{coupon_code}}\nअंतिम तिथि: {{expiry_date}}\n\nअभी रिडीम करें: {{shop_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hi {{customer_name}}, we haven't seen you in 60 days at *{{shop_name}}*!\n\nWe would love to welcome you back with a special high-value offer:\n🔥 {{offer_details}}\n\nUse Code: *{{coupon_code}}*\nValid till: {{expiry_date}}\n\nShop Now: {{shop_link}}"
    tone: "friendly"
    language: "en"
---
Hi {{customer_name}}! 60 din beet gaye, hum aapko miss kar rahe hain at *{{shop_name}}*!

Aapke account mein exclusive VIP comeback perk add kar diya gaya hai:
🔥 {{offer_details}}

Use Code: *{{coupon_code}}*
Valid till: {{expiry_date}}

Claim Now: {{shop_link}}
