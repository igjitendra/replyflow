---
id: retail-low-stock-alert-friendly
title: "Hurry! Low Stock Alert Remaining Pieces — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: low-stock-alert
objective: lead-generation
tone: friendly
language: hinglish
best_time: "10:00-20:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-low-stock-alert-friendly.webp"
meta_title: "Hurry! Low Stock Alert Remaining Pieces... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping low stock alert. Copy, customize variables, and double your reply conversion rates on ReplyFlow."
preview_snippet: "Hi {{customer_name}}! ⚠️ Low Stock Alert at {{shop_name}} ! Aapka wishlist item {{product_name}} tezi se..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant low stock alert touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - shop_name
  - product_name
  - quantity
  - order_link
tags:
  - low-stock
  - stock-alert
  - hurry-up
buttons:
  - type: url
    text: "⚡ Grab Low Stock Unit"
  - type: reply
    text: "📦 Reserve Before Sold Out"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! ⚠️ Low Stock Alert at *{{shop_name}}*!\n\nAapka wishlist item *{{product_name}}* tezi se sale ho raha hai. Bas {{quantity}} units bache hain!\n\nOrder Link: {{order_link}}\n\nStock khatam hone se pehle abhi grab karein!"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! ⚠️ लो स्टॉक अलर्ट! {{product_name}} के सिर्फ {{quantity}} पीस बचे हैं। तुरंत आर्डर करें: {{order_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! ⚠️ Low Stock Warning for {{product_name}} at *{{shop_name}}*!\n\nOnly {{quantity}} left in warehouse. Order now: {{order_link}}"
    tone: "professional"
    language: "en"
---
Hi {{customer_name}}! ⚠️ Low Stock Alert at *{{shop_name}}*!

Aapka wishlist item *{{product_name}}* tezi se sale ho raha hai. Bas {{quantity}} units bache hain!

Order Link: {{order_link}}

Stock khatam hone se pehle abhi grab karein!
