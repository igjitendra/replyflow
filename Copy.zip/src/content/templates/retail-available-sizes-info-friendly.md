---
id: retail-available-sizes-info-friendly
title: "Available Size Chart & Fitting Stock — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: available-sizes-info
objective: support
tone: friendly
language: hinglish
best_time: "09:00-21:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-available-sizes-info-friendly.webp"
meta_title: "Available Size Chart & Fitting Stock (Whatsapp) | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping available sizes info. Copy, customize variables, and double your reply conversion rates on Repl..."
preview_snippet: "Hi {{customer_name}}! 📏 {{product_name}} me current size availability: ✅ Small (S) In Stock ✅ Medium..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant available sizes info touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - product_name
  - amount
tags:
  - size-info
  - size-chart
  - fitting-stock
buttons:
  - type: reply
    text: "📏 Choose My Size"
  - type: reply
    text: "❓ Need Size Assistance"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! 📏 *{{product_name}}* me current size availability:\n\n✅ Small (S) - In Stock\n✅ Medium (M) - In Stock\n✅ Large (L) - In Stock\n✅ Extra Large (XL) - Only 2 Left\n\nPrice: ₹{{amount}}\n\nApna exact size reply karke unit reserve karein!"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! 📏 {{product_name}} के उपलब्ध साइज: S, M, L, XL। अपना साइज चुनकर आर्डर करें!"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! 📏 Size availability for {{product_name}} at *{{shop_name}}*:\n\nSizes in Stock: Small, Medium, Large, XL\nPrice: ₹{{amount}}\n\nReply with your size to hold the stock!"
    tone: "professional"
    language: "en"
---
Hi {{customer_name}}! 📏 *{{product_name}}* me current size availability:

✅ Small (S) - In Stock
✅ Medium (M) - In Stock
✅ Large (L) - In Stock
✅ Extra Large (XL) - Only 2 Left

Price: ₹{{amount}}

Apna exact size reply karke unit reserve karein!
