---
id: retail-colour-specific-recommendation-friendly
title: "Favorite Colour Shade Collection — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: colour-specific-recommendation
objective: lead-generation
tone: friendly
language: hinglish
best_time: "10:00-20:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-colour-specific-recommendation-friendly.webp"
meta_title: "Favorite Colour Shade Collection (Whatsapp) | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping colour specific recommendation. Copy, customize variables, and double your reply conversion rat..."
preview_snippet: "Hi {{customer_name}}! 🎨 Aapke favourite color shade me naye arrival designs at {{shop_name}} ! Color..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant colour specific recommendation touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - shop_name
  - order_link
tags:
  - colour-picks
  - favorite-shade
  - color-curated
buttons:
  - type: url
    text: "🎨 Shop Favorite Color Range"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! 🎨 Aapke favourite color shade me naye arrival designs at *{{shop_name}}*!\n\nColor Collection: {{order_link}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! 🎨 आपके पसंदीदा रंग में नए डिजाइन्स देखें: {{order_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! 🎨 Explore stunning products in your favorite color shade at *{{shop_name}}*: {{order_link}}"
    tone: "professional"
    language: "en"
---
Hi {{customer_name}}! 🎨 Aapke favourite color shade me naye arrival designs at *{{shop_name}}*!

Color Collection: {{order_link}}
