---
id: retail-new-size-range-friendly
title: "Extended Size Options Range (Plus & Kids Sizes) — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: new-size-range
objective: lead-generation
tone: friendly
language: hinglish
best_time: "10:00-20:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-new-size-range-friendly.webp"
meta_title: "Extended Size Options Range (Plus & Kids Sizes)... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping new size range. Copy, customize variables, and double your reply conversion rates on ReplyFlow."
preview_snippet: "New Sizes Now In Stock! 📏 {{product_name}} me ab saare sizes (XS se 5XL) ready..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant new size range touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - product_name
  - shop_name
  - order_link
tags:
  - new-sizes
  - size-range
  - fitting-options
buttons:
  - type: url
    text: "📏 View Full Size Chart"
variations:
  - title: "Hinglish Version"
    text: "New Sizes Now In Stock! 📏\n\n*{{product_name}}* me ab saare sizes (XS se 5XL) ready in stock hain at *{{shop_name}}*!\n\nSize Availability: {{order_link}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "सभी नए साइज उपलब्ध! 📏 {{product_name}} में अब सभी छोटे से बड़े साइज स्टॉक में आ चुके हैं! लिंक: {{order_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Expanded Size Range In Stock! 📏 All size options now available for {{product_name}} at *{{shop_name}}*. Check chart: {{order_link}}"
    tone: "professional"
    language: "en"
---
New Sizes Now In Stock! 📏

*{{product_name}}* me ab saare sizes (XS se 5XL) ready in stock hain at *{{shop_name}}*!

Size Availability: {{order_link}}
