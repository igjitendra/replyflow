---
id: retail-clearance-products-friendly
title: "Stock Clearance Sale Catalogue — Up to {{discount}} OFF at {{shop_name}}"
industry: retail
channel: whatsapp
purpose: clearance-products
objective: lead-generation
tone: friendly
language: hinglish
best_time: "10:00-20:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-clearance-products-friendly.webp"
meta_title: "Stock Clearance Sale Catalogue — Up to  OFF at... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping clearance products. Copy, customize variables, and double your reply conversion rates on ReplyF..."
preview_snippet: "Hi {{customer_name}}! 🔥 Mega Stock Clearance Sale at {{shop_name}} ! Sabhi clearance items par flat..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant clearance products touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - shop_name
  - discount
  - order_link
tags:
  - clearance-sale
  - stock-clearance
  - huge-discounts
buttons:
  - type: url
    text: "🔥 Shop Clearance Sale Catalogue"
  - type: reply
    text: "📦 Reserve Clearance Stock"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! 🔥 Mega Stock Clearance Sale at *{{shop_name}}*!\n\nSabhi clearance items par flat {{discount}} tak ka bhari discount. Stock khtam hone se pehle dekhein:\n\nClearance Catalogue: {{order_link}}\n\nFirst-come, first-served basis!"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! 🔥 *{{shop_name}}* का स्टॉक क्लियरेंस सेल कैटलॉग! {{discount}} तक की भारी छूट। लिंक: {{order_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! 🔥 Massive Clearance Sale at *{{shop_name}}*!\n\nSave up to {{discount}} on final clearance stock.\nBrowse Clearance Catalogue: {{order_link}}"
    tone: "professional"
    language: "en"
---
Hi {{customer_name}}! 🔥 Mega Stock Clearance Sale at *{{shop_name}}*!

Sabhi clearance items par flat {{discount}} tak ka bhari discount. Stock khtam hone se pehle dekhein:

Clearance Catalogue: {{order_link}}

First-come, first-served basis!
