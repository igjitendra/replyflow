---
id: retail-damaged-product-complaint-friendly
title: "Damaged Product Complaint Urgent Action — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: damaged-product-complaint
objective: support
tone: friendly
language: hinglish
best_time: "08:00-21:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-damaged-product-complaint-friendly.webp"
meta_title: "Damaged Product Complaint Urgent Action... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping damaged product complaint. Copy, customize variables, and double your reply conversion rates on..."
preview_snippet: "Hi {{customer_name}}! Aapke {{product_name}} (Order ID: {{order_id}}) ke damage hone ka khed hai. Hum bina..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant damaged product complaint touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - product_name
  - order_id
tags:
  - damaged-product
  - complaint-received
  - free-replacement
buttons:
  - type: reply
    text: "📸 Send Damage Photos"
  - type: reply
    text: "🔄 Request Instant Replacement"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! Aapke *{{product_name}}* (Order ID: {{order_id}}) ke damage hone ka khed hai.\n\nHum bina kisi extra fee ke free replacement de rahe hain. Kripya damage photos share karein!"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! {{product_name}} (Order ID: {{order_id}}) डैमेज निकलने के लिए हमें खेद है। हम मुफ़्त रिप्लेसमेंट दे रहे हैं। कृपया फोटो भेजें!"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! We sincerely apologize for the damaged product {{product_name}} (Order #{{order_id}}). We offer free instant replacement."
    tone: "professional"
    language: "en"
---
Hi {{customer_name}}! Aapke *{{product_name}}* (Order ID: {{order_id}}) ke damage hone ka khed hai.

Hum bina kisi extra fee ke free replacement de rahe hain. Kripya damage photos share karein!
