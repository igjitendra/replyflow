---
id: clinic-maternity-pregnancy-antenatal-checkup-professional-en
title: "Maternity Pregnancy Antenatal Checkup & Ultrasound Alert"
industry: clinic
channel: whatsapp
purpose: maternity-antenatal-checkup
objective: support
tone: professional
language: en
best_time: "09:00-18:00"
whatsapp_approved: true
thumbnail: "/images/templates/clinic-maternity-pregnancy-antenatal-checkup-professional-en.webp"
meta_title: "Maternity Pregnancy Antenatal Checkup & Ultraso... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Healthcare Clinic maternity antenatal checkup. Copy, customize variables, and double your reply conversion rates ..."
preview_snippet: "Dear {{mother_name}}, Congratulations on reaching your {{trimester_stage}} milestone! 🤰✨ This is an automated reminder that..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Healthcare Clinic team needs to execute an instant maternity antenatal checkup touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Healthcare Clinic managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - mother_name
  - trimester_stage
  - doctor_gynaecologist
  - hospital_name
  - due_date
tags:
  - maternity
  - pregnancy
  - antenatal
  - ultrasound
buttons:
  - type: reply
    text: "📅 Confirm Ultrasound Slot"
  - type: url
    text: "📘 Read Pregnancy Care Guide"
  - type: phone
    text: "📞 Call Maternity Desk"
related:
  - clinic-doctor-appointment-booking-confirmation-professional-en
---
Dear {{mother_name}},

Congratulations on reaching your {{trimester_stage}} milestone! 🤰✨

This is an automated reminder that your routine Antenatal Checkup & Growth Ultrasound with Dr. {{doctor_gynaecologist}} at *{{hospital_name}}* is due on **{{due_date}}**.

Important Checkup Tasks:
• Routine Fetal Growth Ultrasound Scan
• Hemoglobin, Blood Sugar & Blood Pressure Monitoring
• Prenatal Vitamins Review

Click below to confirm your appointment time.
