---
id: retail-based-on-previous-purchase-friendly
title: "Personalized Recommendation Based on Past Purchase — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: based-on-previous-purchase
objective: upsell
tone: friendly
language: hinglish
best_time: "10:00-20:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-based-on-previous-purchase-friendly.webp"
meta_title: "Personalized Recommendation Based on Past Purch... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping based on previous purchase. Copy, customize variables, and double your reply conversion rates o..."
preview_snippet: "Hi {{customer_name}}! Aapki pichhli khareeddari ke aadhar par ye products aapko pasand aa sakte hain:..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant based on previous purchase touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - product_name
  - amount
  - order_link
tags:
  - previous-purchase
  - past-orders
  - personalized-recommendation
buttons:
  - type: url
    text: "🛍️ View Personalized Recommendations"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! Aapki pichhli khareeddari ke aadhar par ye products aapko pasand aa sakte hain:\n\n1. *{{product_name}}* – ₹{{amount}}\n2. Matching Combo Item – ₹{{amount}}\n\nPoori collection dekhein: {{order_link}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "Hi {{customer_name}}, आपकी पिछली खरीदारी के आधार पर ये products आपको पसंद आ सकते हैं:\n\n1. {{product_name}} – ₹{{amount}}\n\nपूरी collection देखें: {{order_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hi {{customer_name}}! Based on your past purchase history, here are handpicked products curated just for you:\n\n1. {{product_name}} – ₹{{amount}}\n\nView Full Collection: {{order_link}}"
    tone: "professional"
    language: "en"
---
Hi {{customer_name}}! Aapki pichhli khareeddari ke aadhar par ye products aapko pasand aa sakte hain:

1. *{{product_name}}* – ₹{{amount}}
2. Matching Combo Item – ₹{{amount}}

Poori collection dekhein: {{order_link}}
