---
id: restaurant-abandoned-cart-order-recovery-friendly
title: "Unfinished Food Order & Abandoned Cart Checkout Recovery Nudge"
industry: restaurant
channel: whatsapp
purpose: abandoned-cart-order-recovery
objective: follow-up
tone: friendly
language: hinglish
best_time: "11:00-22:00"
whatsapp_approved: true
thumbnail: "/images/templates/restaurant-abandoned-cart-order-recovery-friendly.webp"
meta_title: "Unfinished Food Order & Abandoned Cart Checkout... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Restaurant & Cafe abandoned cart order recovery. Copy, customize variables, and double your reply conversion rate..."
preview_snippet: "Your Food Cart is Missing You! 🍕😋 Hi {{customer_name}}! We noticed you left your favorite..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Restaurant & Cafe team needs to execute an instant abandoned cart order recovery touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Restaurant & Cafe managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - item_name
  - restaurant_name
  - amount
  - coupon_code
tags:
  - abandoned-cart
  - order-recovery
  - cart-reminder
  - food-cart
buttons:
  - type: reply
    text: "🍕 Complete Order with 10% OFF"
  - type: phone
    text: "📞 Help Me Place Order"
variations:
  - title: "Hinglish Version"
    text: "Your Food is Waiting! 🍕 Hi {{customer_name}}, you left {{item_name}} in your cart at *{{restaurant_name}}*! Complete order now & get flat 10% OFF with code {{coupon_code}}."
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "स्वादिष्ट खाना आपका इंतजार कर रहा है! 🍕 नमस्ते {{customer_name}} जी, आपने *{{restaurant_name}}* में {{item_name}} कार्ट में छोड़ दिया है! आर्डर पूरा करें और 10% छूट पाएं कोड: {{coupon_code}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Your Cart is Missed! 🍕 Dear {{customer_name}}, you left your delicious {{item_name}} in your cart at *{{restaurant_name}}*! Complete your checkout now and get 10% OFF with code {{coupon_code}}."
    tone: "professional"
    language: "en"
related:
  - restaurant-first-order-welcome-offer-friendly
---
Your Food Cart is Missing You! 🍕😋

Hi {{customer_name}}! We noticed you left your favorite *{{item_name}}* in your cart at *{{restaurant_name}}*!

Don't stay hungry! Complete your order right now & enjoy a special recovery reward:

🎁 **Cart Recovery Perks:**
✨ Flat 10% Discount on Cart Total: ₹{{amount}}
✨ Priority Kitchen Prep Slot

🎟️ Use Promo Code: *{{coupon_code}}*

Click below to complete your order in 1 tap!
