---
id: retail-based-on-viewed-product-friendly
title: "Recommendations Based on Recently Browsed Items — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: based-on-viewed-product
objective: lead-generation
tone: friendly
language: hinglish
best_time: "10:00-20:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-based-on-viewed-product-friendly.webp"
meta_title: "Recommendations Based on Recently Browsed Items... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping based on viewed product. Copy, customize variables, and double your reply conversion rates on R..."
preview_snippet: "Hi {{customer_name}}! Aapne recently {{product_name}} at {{shop_name}} dekha tha! Price: ₹{{amount}} Is item ki inventory..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant based on viewed product touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - product_name
  - shop_name
  - amount
  - order_link
tags:
  - recently-viewed
  - browsed-items
  - product-nudge
buttons:
  - type: url
    text: "🛍️ Take a Second Look"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! Aapne recently *{{product_name}}* at *{{shop_name}}* dekha tha!\n\nPrice: ₹{{amount}}\n\nIs item ki inventory limited hai. Catalogue link: {{order_link}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! आपने हाल ही में {{product_name}} देखा था। कीमत: ₹{{amount}}। दोबारा देखें: {{order_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! Still thinking about {{product_name}} at *{{shop_name}}* (₹{{amount}})? Check it out again: {{order_link}}"
    tone: "professional"
    language: "en"
---
Hi {{customer_name}}! Aapne recently *{{product_name}}* at *{{shop_name}}* dekha tha!

Price: ₹{{amount}}

Is item ki inventory limited hai. Catalogue link: {{order_link}}
