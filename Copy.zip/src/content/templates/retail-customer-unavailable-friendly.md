---
id: retail-customer-unavailable-friendly
title: "Customer Unreachable / Door Locked Alert — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: customer-unavailable
objective: support
tone: friendly
language: hinglish
best_time: "09:00-21:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-customer-unavailable-friendly.webp"
meta_title: "Customer Unreachable / Door Locked Alert... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping customer unavailable. Copy, customize variables, and double your reply conversion rates on Repl..."
preview_snippet: "Hi {{customer_name}}! 📞 Rider is trying to call you for Order {{order_id}}! Aapka phone unreachable..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant customer unavailable touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - order_id
tags:
  - unreachable-customer
  - door-closed
  - contact-failed
buttons:
  - type: phone
    text: "📞 Call Delivery Boy Now"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! 📞 Rider is trying to call you for Order #{{order_id}}!\n\nAapka phone unreachable aa raha hai. Kripya rider ko wapas call karein!"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! 📞 आर्डर #{{order_id}} के लिए राइडर आपको कॉल कर रहे हैं। आपका फोन नॉट रीचेबल है।"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! 📞 Delivery executive is at your location for Order #{{order_id}} but unable to reach your phone."
    tone: "professional"
    language: "en"
---
Hi {{customer_name}}! 📞 Rider is trying to call you for Order #{{order_id}}!

Aapka phone unreachable aa raha hai. Kripya rider ko wapas call karein!
