---
id: retail-combo-packs-catalogue-friendly
title: "Value Money Saver Combo Packs Catalogue — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: combo-packs-catalogue
objective: upsell
tone: friendly
language: hinglish
best_time: "10:00-20:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-combo-packs-catalogue-friendly.webp"
meta_title: "Value Money Saver Combo Packs Catalogue... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping combo packs catalogue. Copy, customize variables, and double your reply conversion rates on Rep..."
preview_snippet: "Hi {{customer_name}}! 🎁 Money Saver Combo Packs at {{shop_name}} ! 2 ya 3 items ka..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant combo packs catalogue touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - shop_name
  - discount
  - amount
  - order_link
tags:
  - combo-packs
  - bundle-offer
  - value-pack
buttons:
  - type: url
    text: "🎁 View Combo Packs Catalogue"
  - type: reply
    text: "🛒 Order Combo Pack"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! 🎁 Money Saver Combo Packs at *{{shop_name}}*!\n\n2 ya 3 items ka combo lene par payein flat {{discount}} extra discount. Price starting at ₹{{amount}}.\n\nCombo Catalogue: {{order_link}}\n\nApna favorite combo set aaj hi chunein!"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! 🎁 *{{shop_name}}* के मनी सेवर कॉम्बो पैक्स कैटलॉग! एक्स्ट्रा डिस्काउंट: {{discount}}। कैटलॉग देखें: {{order_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! 🎁 Save bigger with exclusive Combo Packs at *{{shop_name}}*!\n\nEnjoy up to {{discount}} extra savings. Combos start @ ₹{{amount}}.\nBrowse Combos: {{order_link}}"
    tone: "professional"
    language: "en"
---
Hi {{customer_name}}! 🎁 Money Saver Combo Packs at *{{shop_name}}*!

2 ya 3 items ka combo lene par payein flat {{discount}} extra discount. Price starting at ₹{{amount}}.

Combo Catalogue: {{order_link}}

Apna favorite combo set aaj hi chunein!
