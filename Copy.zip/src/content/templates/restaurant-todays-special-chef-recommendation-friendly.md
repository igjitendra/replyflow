---
id: restaurant-todays-special-chef-recommendation-friendly
title: "Today's Special Dishes & Chef's Signature Recommendation"
industry: restaurant
channel: whatsapp
purpose: todays-special-recommendation
objective: upsell
tone: friendly
language: hinglish
best_time: "12:00-20:30"
whatsapp_approved: true
thumbnail: "/images/templates/restaurant-todays-special-chef-recommendation-friendly.webp"
meta_title: "Today's Special Dishes & Chef's Signature Recom... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Restaurant & Cafe todays special recommendation. Copy, customize variables, and double your reply conversion rate..."
preview_snippet: "Hi {{customer_name}}! 👨‍🍳🔥 Aaj kitchen mein chef {{chef_name}} ne banaya hai ek authentic gourmet delight!..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Restaurant & Cafe team needs to execute an instant todays special recommendation touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Restaurant & Cafe managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - chef_name
  - special_dish
  - restaurant_name
  - discount
tags:
  - todays-special
  - chef-recommendation
  - food-offer
  - gourmet-dish
  - restaurant-special
buttons:
  - type: reply
    text: "🍲 Order Today's Special"
  - type: url
    text: "📖 View Full Menu"
  - type: phone
    text: "📞 Call Kitchen Helpline"
variations:
  - title: "Hinglish Version"
    text: |
      Hi {{customer_name}}! 👨‍🍳🔥
      
      Aaj kitchen mein chef *{{chef_name}}* ne banaya hai ek authentic gourmet delight!
      
      🌟 *Today's Chef Recommendation:* *{{special_dish}}* at *{{restaurant_name}}*!
      
      🎁 *Today's Perk:* Get flat *{{discount}}% OFF* on ordering today's special dish!
      
      Freshly prepared & hot! Niche button click karke abhi order ya table reserve karein.
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: |
      नमस्ते {{customer_name}} जी! 👨‍🍳🔥
      
      आज हमारे शेफ *{{chef_name}}* ने आपके लिए तैयार किया है एक बेहद स्वादिष्ट एवं खास व्यंजन!
      
      🌟 *आज की शेफ स्पेशल डिश:* *{{special_dish}}* (*{{restaurant_name}}*)
      
      🎁 *विशेष ऑफर:* आज ही इस स्पेशल डिश पर पाएं *{{discount}}% की सीधी छूट*!
      
      ताज़ा एवं गरमा-गरम स्वाद का आनंद लेने हेतु नीचे दिए बटन पर क्लिक करें।
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: |
      Dear {{customer_name}}, treat your taste buds to culinary perfection! 👨‍🍳🔥
      
      Chef *{{chef_name}}* presents today's signature delight at *{{salon_name}}*:
      
      🌟 *Chef's Special Recommendation:* *{{special_dish}}*
      
      🎁 *Exclusive Today Perk:* Enjoy *{{discount}}% OFF* when you order today's highlight dish.
      
      Tap below to reserve your table or order fresh home delivery.
    tone: "luxury"
    language: "en"
related:
  - restaurant-digital-pdf-qr-menu-sharing-friendly
  - restaurant-lunch-dinner-express-thali-combo-friendly
---
Hi {{customer_name}}! 👨‍🍳🔥

Aaj kitchen mein chef **{{chef_name}}** ne banaya hai ek authentic gourmet delight!

🌟 **Today's Chef Recommendation:** *{{special_dish}}* at *{{restaurant_name}}*!

🎁 **Today's Perk:** Get flat **{{discount}}% OFF** on ordering today's special dish!

Freshly prepared & hot! Niche button click karke abhi order ya table reserve karein.
