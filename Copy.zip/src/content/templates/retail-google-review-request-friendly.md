---
id: retail-google-review-request-friendly
title: "Google Maps Review Request + Bonus Discount — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: google-review-request
objective: retention
tone: friendly
language: hinglish
best_time: "12:00-19:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-google-review-request-friendly.webp"
meta_title: "Google Maps Review Request + Bonus Discount | ReplyFlow"
meta_description: "WhatsApp message template requesting 5-star Google Business review with bonus reward code."
preview_snippet: "Hi {{customer_name}}, hume aapse jud kar khushi hui! Kripya Google par 5-star review share karein aur paaye..."
context_section:
  when_to_use: "Send to happy customers who gave positive feedback to collect public Google reviews."
  target_audience: "Satisfied customers."
  customization_tip: "Add direct Google Business profile review URL."
variables:
  - customer_name
  - shop_name
  - reward_discount
  - google_review_link
tags:
  - google-review
  - rating
  - reputation
  - feedback
buttons:
  - type: url
    text: "⭐ Leave 5-Star Google Review"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! *{{shop_name}}* ke saath aapka experience kaisa raha?\n\nAgar aapko humari service pasand aayi, toh kripya Google par 5-star review dekar support karein!\nReview dene par aapko milega {{reward_discount}} OFF coupon!\n\nGoogle Review Link: {{google_review_link}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! *{{shop_name}}* की सर्विस कैसी लगी? गूगल पर 5-स्टार रिव्यु दें और पाएं {{reward_discount}} का कूपन: {{google_review_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}, thank you for shopping at *{{shop_name}}*! If you enjoyed our service, please leave us a 5-star review on Google: {{google_review_link}}"
    tone: "friendly"
    language: "en"
---
Hi {{customer_name}}! *{{shop_name}}* ke saath aapka experience kaisa raha?

Agar aapko humari service pasand aayi, toh kripya Google par 5-star review dekar support karein!
Review dene par aapko milega {{reward_discount}} OFF coupon!

Google Review Link: {{google_review_link}}
