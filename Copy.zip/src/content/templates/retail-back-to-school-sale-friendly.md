---
id: retail-back-to-school-sale-friendly
title: "Back to School Uniforms & Bags Sale — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: back-to-school-sale
objective: lead-generation
tone: friendly
language: hinglish
best_time: "09:00-20:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-back-to-school-sale-friendly.webp"
meta_title: "Back to School Uniforms & Bags Sale (Whatsapp) | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping back to school sale. Copy, customize variables, and double your reply conversion rates on Reply..."
preview_snippet: "🎒 {{shop_name}} Back To School Sale! School bags, bottles & uniforms par payein {{discount}} OFF!..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant back to school sale touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - shop_name
  - discount
  - date
  - order_link
  - shop_address
tags:
  - back-to-school
  - school-bags
  - uniform-sale
buttons:
  - type: url
    text: "🎒 Shop Back to School"
variations:
  - title: "Hinglish Version"
    text: "🎒 *{{shop_name}}* Back-To-School Sale!\n\nSchool bags, bottles & uniforms par payein {{discount}} OFF!\n\nOffer valid till: {{date}}\nCatalogue: {{order_link}}\nStore Location: {{shop_address}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "🎒 *{{shop_name}}* बैक-टू-स्कूल सेल! स्कूल बैग और बोतलों पर पाएं {{discount}} की छूट। कैटलॉग: {{order_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "🎒 Back-To-School Sale at *{{shop_name}}*! Enjoy UPTO {{discount}} OFF on school supplies till {{date}}. Catalogue: {{order_link}}"
    tone: "professional"
    language: "en"
---
🎒 *{{shop_name}}* Back-To-School Sale!

School bags, bottles & uniforms par payein {{discount}} OFF!

Offer valid till: {{date}}
Catalogue: {{order_link}}
Store Location: {{shop_address}}
