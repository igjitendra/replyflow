---
id: retail-90-day-inactive-customer-friendly
title: "90-Day Inactive Customer Final Churn Prevention Nudge — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: 90-day-inactive-customer
objective: retention
tone: friendly
language: hinglish
best_time: "10:00-18:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-90-day-inactive-customer-friendly.webp"
meta_title: "90-Day Inactive Customer Final Churn Prevention Nudge | ReplyFlow"
meta_description: "Final 90-day re-engagement WhatsApp copy template for long-dormant retail customers."
preview_snippet: "Hi {{customer_name}}, 90 din se aapse mulaqat nahi hui at {{shop_name}}! Aapke liye final maximum discount voucher..."
context_section:
  when_to_use: "Deploy as the final automated win-back step for customers inactive for 90 days."
  target_audience: "Long-term inactive retail customers about to be marked archived."
  customization_tip: "Offer your highest allowable single discount or free gift voucher with short expiry."
variables:
  - customer_name
  - shop_name
  - offer_details
  - coupon_code
  - expiry_date
  - shop_link
tags:
  - 90-day-inactive
  - final-nudge
  - churn-recovery
  - maximum-discount
buttons:
  - type: url
    text: "🔥 Claim Final 90-Day Offer"
  - type: reply
    text: "🛑 Unsubscribe Updates"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}, 90 din se aapse mulaqat nahi hui at *{{shop_name}}*!\n\nAapke liye humara maximum comeback discount voucher active hai:\n💥 {{offer_details}}\n\nUse Code: *{{coupon_code}}*\nExpiry Date: {{expiry_date}}\n\nClaim Before Expiry: {{shop_link}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी, 90 दिन से आपसे मुलाकात नहीं हुई!\n\nआपके लिए हमारा स्पेशल वापसी डिस्काउंट एक्टिव है:\n💥 {{offer_details}}\n\nकूपन कोड: {{coupon_code}}\nअंतिम तिथि: {{expiry_date}}\n\nअभी रिडीम करें: {{shop_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}, it has been 90 days since your last purchase at *{{shop_name}}*!\n\nHere is our ultimate win-back voucher created especially for you:\n💥 {{offer_details}}\n\nUse Code: *{{coupon_code}}*\nValid until: {{expiry_date}}\n\nShop Now: {{shop_link}}"
    tone: "friendly"
    language: "en"
---
Hi {{customer_name}}, 90 din se aapse mulaqat nahi hui at *{{shop_name}}*!

Aapke liye humara maximum comeback discount voucher active hai:
💥 {{offer_details}}

Use Code: *{{coupon_code}}*
Expiry Date: {{expiry_date}}

Claim Before Expiry: {{shop_link}}
