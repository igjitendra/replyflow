---
id: retail-available-colours-info-friendly
title: "Available Colour Variants & Shade Options — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: available-colours-info
objective: support
tone: friendly
language: hinglish
best_time: "09:00-21:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-available-colours-info-friendly.webp"
meta_title: "Available Colour Variants & Shade Options... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping available colours info. Copy, customize variables, and double your reply conversion rates on Re..."
preview_snippet: "Hi {{customer_name}}! 🎨 {{product_name}} ke available color variants: 🔴 Red | 🔵 Navy Blue |..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant available colours info touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - product_name
  - amount
tags:
  - colour-variants
  - shades
  - colour-options
buttons:
  - type: reply
    text: "🎨 Select My Color"
  - type: reply
    text: "📸 Request Color Photos"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! 🎨 *{{product_name}}* ke available color variants:\n\n🔴 Red | 🔵 Navy Blue | ⚫ Classic Black | ⚪ Off-White\n\nPrice: ₹{{amount}}\n\nAapko kaunsa shade pasand hai? Color name reply karein!"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! 🎨 {{product_name}} के उपलब्ध रंग: लाल, नेवी ब्लू, काला और सफ़ेद। अपना पसंदीदा रंग चुनें!"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! 🎨 Available colours for {{product_name}} at *{{shop_name}}*:\n\nAvailable Shades: Red, Navy Blue, Black, White\nPrice: ₹{{amount}}\n\nReply with your preferred colour!"
    tone: "professional"
    language: "en"
---
Hi {{customer_name}}! 🎨 *{{product_name}}* ke available color variants:

🔴 Red | 🔵 Navy Blue | ⚫ Classic Black | ⚪ Off-White

Price: ₹{{amount}}

Aapko kaunsa shade pasand hai? Color name reply karein!
