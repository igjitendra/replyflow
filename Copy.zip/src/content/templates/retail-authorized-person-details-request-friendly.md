---
id: retail-authorized-person-details-request-friendly
title: "Authorized Representative Pickup Registration — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: authorized-person-details-request
objective: support
tone: friendly
language: hinglish
best_time: "09:00-21:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-authorized-person-details-request-friendly.webp"
meta_title: "Authorized Representative Pickup Registration... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping authorized person details request. Copy, customize variables, and double your reply conversion ..."
preview_snippet: "Hi {{customer_name}}! 👤 Authorized Representative Pickup for Order {{order_id}}: Agar aapki jagah koi friend, relative..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant authorized person details request touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - order_id
tags:
  - authorized-pickup
  - representative-name
  - proxy-pickup
buttons:
  - type: reply
    text: "👤 Provide Friend/Driver Name"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! 👤 Authorized Representative Pickup for Order #{{order_id}}:\n\nAgar aapki jagah koi friend, relative ya driver parcel lene aa rahe hain, toh unka Full Name & Mobile Number reply karein!"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! 👤 अगर आपके बदले कोई और आर्डर लेने आ रहा है, तो उनका नाम और फोन नंबर भेजें!"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! 👤 If sending a representative to pick up Order #{{order_id}}, please share their Name & Phone number."
    tone: "professional"
    language: "en"
---
Hi {{customer_name}}! 👤 Authorized Representative Pickup for Order #{{order_id}}:

Agar aapki jagah koi friend, relative ya driver parcel lene aa rahe hain, toh unka Full Name & Mobile Number reply karein!
