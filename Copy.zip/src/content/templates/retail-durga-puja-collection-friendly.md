---
id: retail-durga-puja-collection-friendly
title: "Durga Puja Festive Wear & Gifts Collection — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: durga-puja-collection
objective: lead-generation
tone: friendly
language: hinglish
best_time: "09:00-20:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-durga-puja-collection-friendly.webp"
meta_title: "Durga Puja Festive Wear & Gifts Collection... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping durga puja collection. Copy, customize variables, and double your reply conversion rates on Rep..."
preview_snippet: "🌺 {{shop_name}} Durga Puja Sharad Utsav Special! Pujo festive collection & gifts par payein {{discount}}..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant durga puja collection touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - shop_name
  - discount
  - date
  - order_link
  - shop_address
tags:
  - durga-puja
  - sharad-utsav
  - pujo-collection
buttons:
  - type: url
    text: "🌺 Shop Durga Puja Collection"
variations:
  - title: "Hinglish Version"
    text: "🌺 *{{shop_name}}* Durga Puja Sharad Utsav Special!\n\nPujo festive collection & gifts par payein {{discount}} OFF!\n\nOffer valid till: {{date}}\nCatalogue: {{order_link}}\nStore Address: {{shop_address}}\n\nSubho Sharadiya!"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "🌺 *{{shop_name}}* दुर्गा पूजा शरद उत्सव कलेक्शन! पुजो शॉपिंग पर पाएं {{discount}} की विशेष छूट। कैटलॉग: {{order_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "🌺 Subho Sharadiya from *{{shop_name}}*! Shop Durga Puja collection with UPTO {{discount}} OFF till {{date}}. Catalogue: {{order_link}}"
    tone: "professional"
    language: "en"
---
🌺 *{{shop_name}}* Durga Puja Sharad Utsav Special!

Pujo festive collection & gifts par payein {{discount}} OFF!

Offer valid till: {{date}}
Catalogue: {{order_link}}
Store Address: {{shop_address}}

Subho Sharadiya!
