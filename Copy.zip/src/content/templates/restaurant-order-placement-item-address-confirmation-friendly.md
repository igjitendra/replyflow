---
id: restaurant-order-placement-item-address-confirmation-friendly
title: "Order Summary, Address & Final Confirmation Request"
industry: restaurant
channel: whatsapp
purpose: order-summary-address-confirmation
objective: support
tone: friendly
language: hinglish
best_time: "11:00-22:30"
whatsapp_approved: true
thumbnail: "/images/templates/restaurant-order-placement-item-address-confirmation-friendly.webp"
meta_title: "Order Summary, Address & Final Confirmation Req... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Restaurant & Cafe order summary address confirmation. Copy, customize variables, and double your reply conversion..."
preview_snippet: "Namaste {{customer_name}} ji! 🛍️✨ Kripya apna {{restaurant_name}} order details verify & confirm karein: 📋 Order..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Restaurant & Cafe team needs to execute an instant order summary address confirmation touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Restaurant & Cafe managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - restaurant_name
  - order_items
  - quantity
  - amount
  - address
tags:
  - order-confirmation
  - address-confirmation
  - order-summary
  - whatsapp-order
  - food-order
buttons:
  - type: reply
    text: "✅ CONFIRM ORDER"
  - type: reply
    text: "✏️ Edit Items / Address"
  - type: phone
    text: "📞 Call Kitchen Helpline"
variations:
  - title: "Hinglish Version"
    text: |
      Namaste {{customer_name}} ji! 🛍️✨
      
      Kripya apna *{{restaurant_name}}* order details verify & confirm karein:
      
      📋 *Order Items:* {{order_items}}
      🔢 *Quantity:* {{quantity}}
      💰 *Total Amount:* ₹{{amount}}
      📍 *Delivery Address:* {{address}}
      
      Order confirm karne ke liye niche *CONFIRM ORDER* button par click karein ya *CONFIRM* reply karein!
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: |
      नमस्ते {{customer_name}} जी! 🛍️✨
      
      कृपया अपना *{{restaurant_name}}* ऑर्डर विवरण सत्यापित एवं कन्फर्म करें:
      
      📋 *ऑर्डर सामग्री:* {{order_items}}
      🔢 *मात्रा:* {{quantity}}
      💰 *कुल राशि:* ₹{{amount}}
      📍 *डिलीवरी पता:* {{address}}
      
      ऑर्डर कन्फर्म करने के लिए नीचे *CONFIRM ORDER* बटन पर क्लिक करें या *CONFIRM* लिखकर रिप्लाई करें।
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: |
      Dear {{customer_name}}, please review and confirm your food order with *{{restaurant_name}}*: 🛍️✨
      
      📋 *Ordered Items:* {{order_items}}
      🔢 *Quantity:* {{quantity}}
      💰 *Total Payable:* ₹{{amount}}
      📍 *Delivery Address:* {{address}}
      
      Tap *CONFIRM ORDER* below or reply *CONFIRM* to place your order into the kitchen.
    tone: "professional"
    language: "en"
related:
  - restaurant-food-customization-spice-level-addons-friendly
  - restaurant-location-pin-contactless-preference-friendly
---
Namaste {{customer_name}} ji! 🛍️✨

Kripya apna **{{restaurant_name}}** order details verify & confirm karein:

📋 **Order Items:** {{order_items}}
🔢 **Quantity:** {{quantity}}
💰 **Total Amount:** ₹{{amount}}
📍 **Delivery Address:** {{address}}

Order confirm karne ke liye niche **CONFIRM ORDER** button par click karein ya **CONFIRM** reply karein!
