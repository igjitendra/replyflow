---
id: retail-exam-season-stationery-offer-friendly
title: "Exam Season Books & Stationery Discount — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: exam-season-stationery-offer
objective: lead-generation
tone: friendly
language: hinglish
best_time: "09:00-20:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-exam-season-stationery-offer-friendly.webp"
meta_title: "Exam Season Books & Stationery Discount... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping exam season stationery offer. Copy, customize variables, and double your reply conversion rates..."
preview_snippet: "📚 {{shop_name}} Exam Special Stationery Offers! Notebooks, pens & exam kits par payein {{discount}} OFF!..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant exam season stationery offer touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - shop_name
  - discount
  - date
  - order_link
  - shop_address
tags:
  - exam-season
  - stationery-sale
  - books-discount
buttons:
  - type: url
    text: "📚 Shop Exam Stationery"
variations:
  - title: "Hinglish Version"
    text: "📚 *{{shop_name}}* Exam Special Stationery Offers!\n\nNotebooks, pens & exam kits par payein {{discount}} OFF!\n\nOffer valid till: {{date}}\nCatalogue: {{order_link}}\nStore Address: {{shop_address}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "📚 *{{shop_name}}* परीक्षा स्पेशल स्टेशनरी ऑफर! कॉपी-किताबों व पेन पर पाएं {{discount}} की छूट। कैटलॉग: {{order_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "📚 Exam Season Stationery Sale at *{{shop_name}}*! Get UPTO {{discount}} OFF on notebooks & stationery till {{date}}. Catalogue: {{order_link}}"
    tone: "professional"
    language: "en"
---
📚 *{{shop_name}}* Exam Special Stationery Offers!

Notebooks, pens & exam kits par payein {{discount}} OFF!

Offer valid till: {{date}}
Catalogue: {{order_link}}
Store Address: {{shop_address}}
