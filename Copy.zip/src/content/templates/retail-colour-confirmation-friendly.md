---
id: retail-colour-confirmation-friendly
title: "Product Colour Shade Confirmation — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: colour-confirmation
objective: support
tone: friendly
language: hinglish
best_time: "09:00-21:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-colour-confirmation-friendly.webp"
meta_title: "Product Colour Shade Confirmation (Whatsapp) | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping colour confirmation. Copy, customize variables, and double your reply conversion rates on Reply..."
preview_snippet: "Hi {{customer_name}}! 🎨 {{product_name}} Colour Selection: Aapko kaunsa color shade pack karwana hai? Available: Black,..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant colour confirmation touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - product_name
tags:
  - colour-confirmation
  - shade-confirm
  - color-option
buttons:
  - type: reply
    text: "⚫ Black"
  - type: reply
    text: "🔵 Blue"
  - type: reply
    text: "🔴 Red"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! 🎨 *{{product_name}}* Colour Selection:\n\nAapko kaunsa color shade pack karwana hai? Available: Black, Blue, Red, White.\n\nReply karke color confirm karein!"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! 🎨 {{product_name}} के लिए अपना पसंदीदा रंग चुनें!"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! 🎨 Please confirm your chosen color shade for {{product_name}} at *{{shop_name}}*."
    tone: "professional"
    language: "en"
---
Hi {{customer_name}}! 🎨 *{{product_name}}* Colour Selection:

Aapko kaunsa color shade pack karwana hai? Available: Black, Blue, Red, White.

Reply karke color confirm karein!
