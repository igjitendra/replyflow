---
id: retail-limited-stock-products-friendly
title: "Hurry! Limited Stock Remaining Catalogue — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: limited-stock-products
objective: lead-generation
tone: friendly
language: hinglish
best_time: "10:00-20:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-limited-stock-products-friendly.webp"
meta_title: "Hurry! Limited Stock Remaining Catalogue... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping limited stock products. Copy, customize variables, and double your reply conversion rates on Re..."
preview_snippet: "Hi {{customer_name}}! ⏰ Limited Stock Alert at {{shop_name}} ! Item: {{product_name}} ⚠️ Only {{quantity}} pieces..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant limited stock products touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - shop_name
  - product_name
  - quantity
  - order_link
tags:
  - limited-stock
  - hurry-up
  - last-few-left
buttons:
  - type: url
    text: "⏰ Grab Limited Stock Now"
  - type: reply
    text: "📦 Reserve My Piece"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! ⏰ Limited Stock Alert at *{{shop_name}}*!\n\nItem: *{{product_name}}*\n⚠️ Only {{quantity}} pieces left in stock!\n\nLimited Stock Catalogue: {{order_link}}\n\nStock khatam hone se pehle fast book karein!"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! ⏰ *{{shop_name}}* में स्टॉक सीमित है! सिर्फ {{quantity}} पीस बचे हैं। कैटलॉग: {{order_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! ⏰ Hurry! Almost Sold Out at *{{shop_name}}*!\n\nOnly {{quantity}} units left of {{product_name}}.\nView Catalogue: {{order_link}}"
    tone: "professional"
    language: "en"
---
Hi {{customer_name}}! ⏰ Limited Stock Alert at *{{shop_name}}*!

Item: *{{product_name}}*
⚠️ Only {{quantity}} pieces left in stock!

Limited Stock Catalogue: {{order_link}}

Stock khatam hone se pehle fast book karein!
