---
id: restaurant-weekend-special-combo-offer-friendly
title: "Weekend Family Feast & Pizza/Biryani Combo Offer"
industry: restaurant
channel: whatsapp
purpose: weekend-special-combo-offer
objective: lead-generation
tone: friendly
language: hinglish
best_time: "11:00-20:00"
whatsapp_approved: true
thumbnail: "/images/templates/restaurant-weekend-special-combo-offer-friendly.webp"
meta_title: "Weekend Family Feast & Pizza/Biryani Combo Offe... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Restaurant & Cafe weekend special combo offer. Copy, customize variables, and double your reply conversion rates ..."
preview_snippet: "Weekend Foodie Fest! 🍕🍔🎉 Hi {{customer_name}}! Make your weekend delicious with {{restaurant_name}} Super Weekend Feast..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Restaurant & Cafe team needs to execute an instant weekend special combo offer touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Restaurant & Cafe managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - restaurant_name
  - item_name
  - amount
  - coupon_code
tags:
  - weekend-offer
  - family-combo
  - pizza-combo
  - biryani-feast
buttons:
  - type: reply
    text: "🍕 Claim Weekend Combo"
  - type: url
    text: "📜 View Full Weekend Menu"
variations:
  - title: "Hinglish Version"
    text: "Weekend Foodie Fest! 🍕 Hi {{customer_name}}, treat your family with *{{restaurant_name}}* Weekend Special {{item_name}} Combo @ just ₹{{amount}}! Use promo code {{coupon_code}}."
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "वीकेंड स्पेशल ऑफर! 🍕 नमस्ते {{customer_name}} जी, *{{restaurant_name}}* का वीकेंड स्पेशल {{item_name}} कॉम्बो मात्र ₹{{amount}} में ऑर्डर करें। कूपन कोड: {{coupon_code}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Weekend Food Festival! 🍕 Dear {{customer_name}}, treat your friends & family with *{{restaurant_name}}* Weekend Special {{item_name}} Combo at just ₹{{amount}}! Use code {{coupon_code}}."
    tone: "professional"
    language: "en"
related:
  - restaurant-first-order-welcome-offer-friendly
---
Weekend Foodie Fest! 🍕🍔🎉

Hi {{customer_name}}! Make your weekend delicious with *{{restaurant_name}}* **Super Weekend Feast Combo**:

✨ {{item_name}}
✨ 2 Complimentary Fresh Chilled Mocktails / Drinks
✨ Free Garlic Bread / Chocolate Lava Cake

🎁 Weekend Special Price: ₹{{amount}} (Flat 30% Savings)
🎟️ Use Promo Code: *{{coupon_code}}*

Click below to order your weekend feast now!
