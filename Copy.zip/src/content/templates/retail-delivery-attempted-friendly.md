---
id: retail-delivery-attempted-friendly
title: "Delivery Attempted Notice & Re-delivery Request — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: delivery-attempted
objective: support
tone: friendly
language: hinglish
best_time: "09:00-21:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-delivery-attempted-friendly.webp"
meta_title: "Delivery Attempted Notice & Re-delivery Request... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping delivery attempted. Copy, customize variables, and double your reply conversion rates on ReplyF..."
preview_snippet: "Hi {{customer_name}}! 🔔 Delivery Attempted Notice for Order {{order_id}}! Rider aapke address par pahuche the..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant delivery attempted touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - order_id
tags:
  - delivery-attempted
  - re-delivery
  - door-closed
buttons:
  - type: reply
    text: "🔄 Re-attempt Tomorrow"
  - type: phone
    text: "📞 Call Delivery Rider"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! 🔔 Delivery Attempted Notice for Order #{{order_id}}!\n\nRider aapke address par pahuche the par door lock / no response mila.\n\nKripya re-delivery time confirm karne ke liye reply karein!"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! 🔔 आपके आर्डर #{{order_id}} के लिए डिलीवरी का प्रयास किया गया था लेकिन संपर्क नहीं हो सका।"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! 🔔 Delivery was attempted for Order #{{order_id}} at your address. Reply to schedule re-delivery."
    tone: "professional"
    language: "en"
---
Hi {{customer_name}}! 🔔 Delivery Attempted Notice for Order #{{order_id}}!

Rider aapke address par pahuche the par door lock / no response mila.

Kripya re-delivery time confirm karne ke liye reply karein!
