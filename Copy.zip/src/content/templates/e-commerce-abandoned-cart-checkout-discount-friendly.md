---
id: e-commerce-abandoned-cart-checkout-discount-friendly
title: "15-Min Abandoned Cart Recovery + Instant 10% Discount — {{store_name}}"
industry: e-commerce
channel: whatsapp
purpose: abandoned-cart-recovery
objective: retention
tone: friendly
language: hinglish
best_time: "09:00-22:00"
whatsapp_approved: true
thumbnail: "/images/templates/e-commerce-abandoned-cart-checkout-discount-friendly.webp"
meta_title: "15-Min Abandoned Cart Recovery + Instant 10% Discount | ReplyFlow"
meta_description: "WhatsApp e-commerce abandoned cart recovery template with instant coupon code and 1-click checkout."
preview_snippet: "Hi {{customer_name}}, aapke cart mein {{item_name}} waiting par hai! Checkout complete karein aur paaye..."
context_section:
  when_to_use: "Send 15-30 minutes after customer leaves items in e-commerce cart."
  target_audience: "Shoppers with abandoned carts."
  customization_tip: "Offer limited-time 10% OFF promo code."
variables:
  - customer_name
  - store_name
  - item_name
  - coupon_code
  - checkout_link
tags:
  - abandoned-cart
  - e-commerce
  - recovery-discount
  - promo-code
buttons:
  - type: url
    text: "🛒 Complete Checkout with 10% OFF"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! 🛒✨\n\nAapke cart mein *{{item_name}}* wahi chhoot gaya tha!\n\nFinish checkout in the next 2 hours & use Code *{{coupon_code}}* for instant 10% OFF!\n\nCheckout Now: {{checkout_link}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! आपकी कार्ट में *{{item_name}}* आपका इंतजार कर रहा है। कोड *{{coupon_code}}* से 10% अतिरिक्त छूट पाएं: {{checkout_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! You left *{{item_name}}* in your cart at *{{store_name}}*. Complete purchase now using promo code *{{coupon_code}}* for 10% OFF: {{checkout_link}}"
    tone: "friendly"
    language: "en"
---
Hi {{customer_name}}! 🛒✨

Aapke cart mein *{{item_name}}* wahi chhoot gaya tha!

Finish checkout in the next 2 hours & use Code *{{coupon_code}}* for instant 10% OFF!

Checkout Now: {{checkout_link}}
