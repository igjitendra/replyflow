---
id: retail-customer-specific-offer-friendly
title: "Personalized Customer-Specific Offer — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: customer-specific-offer
objective: retention
tone: friendly
language: hinglish
best_time: "10:00-19:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-customer-specific-offer-friendly.webp"
meta_title: "Personalized Customer-Specific Offer | ReplyFlow"
meta_description: "1-on-1 personalized discount offer WhatsApp template based on customer purchase history."
preview_snippet: "Hi {{customer_name}}, humne specially aapke liye ek exclusive offer create kiya hai at {{shop_name}}..."
context_section:
  when_to_use: "Use when creating tailored targeted campaigns for specific high-value customer segments."
  target_audience: "Specific customer cohorts."
  customization_tip: "Mention preferred product category."
variables:
  - customer_name
  - shop_name
  - offer_details
  - coupon_code
  - expiry_date
  - shop_link
tags:
  - personalized-offer
  - tailored-deal
  - retention
buttons:
  - type: url
    text: "🎁 Claim My Personalized Offer"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! Humne specially aapke liye *{{shop_name}}* par ek 1-on-1 personalized offer tailor kiya hai:\n\n🔥 {{offer_details}}\n\nUse Secret Code: *{{coupon_code}}*\nValid till: {{expiry_date}}\n\nClaim Now: {{shop_link}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! हमने विशेष रूप से आपके लिए एक स्पेशल ऑफर तैयार किया है: {{offer_details}}। कूपन: {{coupon_code}}। देखें: {{shop_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}, we have created a special 1-on-1 personalized offer just for you at *{{shop_name}}*:\n🔥 {{offer_details}}\nUse Code: *{{coupon_code}}*\nValid until: {{expiry_date}}\n\nShop Now: {{shop_link}}"
    tone: "friendly"
    language: "en"
---
Hi {{customer_name}}! Humne specially aapke liye *{{shop_name}}* par ek 1-on-1 personalized offer tailor kiya hai:

🔥 {{offer_details}}

Use Secret Code: *{{coupon_code}}*
Valid till: {{expiry_date}}

Claim Now: {{shop_link}}
