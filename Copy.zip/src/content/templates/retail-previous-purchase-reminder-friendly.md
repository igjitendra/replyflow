---
id: retail-previous-purchase-reminder-friendly
title: "Previous Purchase Repeat Order Reminder — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: previous-purchase-reminder
objective: retention
tone: friendly
language: hinglish
best_time: "10:00-19:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-previous-purchase-reminder-friendly.webp"
meta_title: "Previous Purchase Repeat Order Reminder | ReplyFlow"
meta_description: "Automated WhatsApp repeat order nudge based on customer's last item purchased."
preview_snippet: "Hi {{customer_name}}, aapne pehle purchase kiya tha {{product_name}}. Refill ya repeat order ke liye click karein..."
context_section:
  when_to_use: "Send when a consumable or recurring item is due for re-order."
  target_audience: "Repeat buyers."
  customization_tip: "Include 1-click reorder link."
variables:
  - customer_name
  - shop_name
  - product_name
  - discount
  - reorder_link
tags:
  - repeat-purchase
  - reorder
  - customer-retention
buttons:
  - type: url
    text: "🔄 Re-order {{product_name}}"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! Aapne pehle *{{shop_name}}* se *{{product_name}}* buy kiya tha.\n\nKya aapko stock refill chahiye? Instant re-order par paaye {{discount}} OFF!\n\nReorder Link: {{reorder_link}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! आपने पहले *{{product_name}}* ख़रीदा था। दोबारा आर्डर करने के लिए यहाँ क्लिक करें: {{reorder_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! Running low on *{{product_name}}*? Re-order now from *{{shop_name}}* and get {{discount}} OFF: {{reorder_link}}"
    tone: "friendly"
    language: "en"
---
Hi {{customer_name}}! Aapne pehle *{{shop_name}}* se *{{product_name}}* buy kiya tha.

Kya aapko stock refill chahiye? Instant re-order par paaye {{discount}} OFF!

Reorder Link: {{reorder_link}}
