---
id: retail-dussehra-offer-friendly
title: "Vijayadashami Dussehra Victory Discounts — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: dussehra-offer
objective: lead-generation
tone: friendly
language: hinglish
best_time: "09:00-20:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-dussehra-offer-friendly.webp"
meta_title: "Vijayadashami Dussehra Victory Discounts... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping dussehra offer. Copy, customize variables, and double your reply conversion rates on ReplyFlow."
preview_snippet: "🏹 {{shop_name}} Vijayadashami Dussehra Special Sale! Shubh khareeddari par payein FLAT {{discount}} OFF! Offer valid..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant dussehra offer touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - shop_name
  - discount
  - date
  - order_link
  - shop_address
tags:
  - dussehra-sale
  - vijayadashami
  - festive-offers
buttons:
  - type: url
    text: "🏹 Shop Dussehra Victory Sale"
variations:
  - title: "Hinglish Version"
    text: "🏹 *{{shop_name}}* Vijayadashami Dussehra Special Sale!\n\nShubh khareeddari par payein FLAT {{discount}} OFF!\n\nOffer valid till: {{date}}\nCatalogue: {{order_link}}\nStore Location: {{shop_address}}\n\nHappy Dussehra!"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "🏹 *{{shop_name}}* विजयादशमी दशहरा स्पेशल सेल! शुभ खरीदारी पर पाएं {{discount}} की छूट। कैटलॉग: {{order_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "🏹 Dussehra Blessings from *{{shop_name}}*! Enjoy FLAT {{discount}} OFF on festive purchases till {{date}}. Catalogue: {{order_link}}"
    tone: "professional"
    language: "en"
---
🏹 *{{shop_name}}* Vijayadashami Dussehra Special Sale!

Shubh khareeddari par payein FLAT {{discount}} OFF!

Offer valid till: {{date}}
Catalogue: {{order_link}}
Store Location: {{shop_address}}

Happy Dussehra!
