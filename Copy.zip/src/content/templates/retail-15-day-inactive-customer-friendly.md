---
id: retail-15-day-inactive-customer-friendly
title: "15-Day Inactive Customer Gentle Nudge & Comeback Discount — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: 15-day-inactive-customer
objective: retention
tone: friendly
language: hinglish
best_time: "11:00-19:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-15-day-inactive-customer-friendly.webp"
meta_title: "15-Day Inactive Customer Gentle Nudge & Comeback Discount | ReplyFlow"
meta_description: "Ready-to-use WhatsApp template to re-engage customers inactive for 15 days with personalized recommendations and coupon code."
preview_snippet: "Hi {{customer_name}}, kafi samay se aapki shopping nahi hui at {{shop_name}}! Aapke favourite products par special comeback offer..."
context_section:
  when_to_use: "Send this automated touchpoint when a registered retail customer hasn't purchased anything for 15 consecutive days."
  target_audience: "Retail customers who previously bought or browsed items."
  customization_tip: "Include a direct 1-click WhatsApp CTA button with coupon auto-applied."
variables:
  - customer_name
  - shop_name
  - offer_details
  - coupon_code
  - expiry_date
  - shop_link
tags:
  - customer-retention
  - re-engagement
  - inactive-customer
  - comeback-offer
buttons:
  - type: url
    text: "🛍️ Shop Comeback Offer Now"
  - type: reply
    text: "💬 Chat with Support"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}, kafi samay se aapki shopping nahi hui at *{{shop_name}}*!\n\nAapke favourite products par special comeback offer:\n🔥 {{offer_details}}\n\nUse Code: *{{coupon_code}}*\nValid till: {{expiry_date}}\n\nClaim Now: {{shop_link}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी, काफी समय से आपकी shopping नहीं हुई!\n\nआपके favourite products पर special comeback offer:\n🔥 {{offer_details}}\n\nCode: {{coupon_code}}\nValid till: {{expiry_date}}\n\nअभी देखें: {{shop_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hi {{customer_name}}, we miss seeing you at *{{shop_name}}*!\n\nHere is an exclusive comeback offer just for you:\n🔥 {{offer_details}}\n\nUse Code: *{{coupon_code}}*\nValid till: {{expiry_date}}\n\nShop Now: {{shop_link}}"
    tone: "friendly"
    language: "en"
---
Hi {{customer_name}}, kafi samay se aapki shopping nahi hui at *{{shop_name}}*!

Aapke favourite products par special comeback offer:
🔥 {{offer_details}}

Use Code: *{{coupon_code}}*
Valid till: {{expiry_date}}

Claim Now: {{shop_link}}
