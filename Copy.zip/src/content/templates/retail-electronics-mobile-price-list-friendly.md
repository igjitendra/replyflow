---
id: retail-electronics-mobile-price-list-friendly
title: "Latest Mobile Price List & Best Deal Catalogue — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: mobile-price-list
objective: lead-generation
tone: friendly
language: hinglish
best_time: "10:00-20:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-electronics-mobile-price-list-friendly.webp"
meta_title: "Latest Mobile Price List & Best Deal Catalogue | ReplyFlow"
meta_description: "WhatsApp template for sharing updated smartphone price lists and festival discount catalogues."
preview_snippet: "Namaste {{customer_name}}! 📱 Aaj ki updated Mobile Price List *{{shop_name}}* par ready hai..."
context_section:
  when_to_use: "Send when a customer asks for smartphone prices or monthly updated rate lists."
  target_audience: "Prospective mobile buyers."
  customization_tip: "Attach PDF price list or direct online catalogue link."
variables:
  - customer_name
  - shop_name
  - brand_name
  - starting_price
  - price_list_link
tags:
  - mobile-price-list
  - smartphone-rate
  - electronics-catalogue
  - mobile-shop
buttons:
  - type: url
    text: "📱 View Mobile Price List"
  - type: reply
    text: "💳 Ask for EMI Options"
variations:
  - title: "Hinglish Version"
    text: "Namaste {{customer_name}}! 📱✨\n\n*{{shop_name}}* par sabhi top brand *{{brand_name}}* smartphones ki updated price list ready hai!\n\nStarting Price: *₹{{starting_price}}*\nZero Down Payment EMI available!\n\nFull Price List & Catalog: {{price_list_link}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! *{{shop_name}}* पर नए स्मार्टफोन्स की ताज़ा प्राइस लिस्ट उपलब्ध है: {{price_list_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! Check out the updated mobile price list for *{{brand_name}}* at *{{shop_name}}*: {{price_list_link}}"
    tone: "friendly"
    language: "en"
---
Namaste {{customer_name}}! 📱✨

*{{shop_name}}* par sabhi top brand *{{brand_name}}* smartphones ki updated price list ready hai!

Starting Price: *₹{{starting_price}}*
Zero Down Payment EMI available!

Full Price List & Catalog: {{price_list_link}}
