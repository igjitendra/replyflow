---
id: restaurant-table-cancellation-reschedule-friendly
title: "Table Reservation Cancellation Confirmation & Easy Reschedule Link"
industry: restaurant
channel: whatsapp
purpose: table-cancellation-reschedule
objective: support
tone: friendly
language: hinglish
best_time: "10:00-21:00"
whatsapp_approved: true
thumbnail: "/images/templates/restaurant-table-cancellation-reschedule-friendly.webp"
meta_title: "Table Reservation Cancellation Confirmation & E... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Restaurant & Cafe table cancellation reschedule. Copy, customize variables, and double your reply conversion rate..."
preview_snippet: "Reservation Cancelled. 🍽️ Dear {{customer_name}}, as per your request, your table reservation at {{restaurant_name}} for..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Restaurant & Cafe team needs to execute an instant table cancellation reschedule touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Restaurant & Cafe managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - restaurant_name
  - date
  - time
tags:
  - table-cancellation
  - reschedule-booking
  - dining-cancellation
  - reservation
buttons:
  - type: reply
    text: "📅 Reschedule Table Booking"
  - type: phone
    text: "📞 Call Restaurant Desk"
variations:
  - title: "Hinglish Version"
    text: "Reservation Cancelled. 🍽️ Hi {{customer_name}}, your table reservation for {{date}} @ {{time}} at *{{restaurant_name}}* has been cancelled as requested. Hope to host you soon!"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "आरक्षण रद्द। 🍽️ नमस्ते {{customer_name}} जी, *{{restaurant_name}}* में दिनांक {{date}} समय {{time}} हेतु आपकी टेबल बुकिंग आपके अनुरोध अनुसार रद्द कर दी गई है।"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Reservation Cancelled. Dear {{customer_name}}, your table reservation for {{date}} at {{time}} with *{{restaurant_name}}* has been cancelled as requested. We hope to serve you soon!"
    tone: "professional"
    language: "en"
related:
  - restaurant-table-reservation-confirmation-friendly
---
Reservation Cancelled. 🍽️

Dear {{customer_name}}, as per your request, your table reservation at *{{restaurant_name}}* for **{{date}} at {{time}}** has been successfully cancelled.

We miss hosting you! If your plans change, you can easily reschedule your dining table for another date or time.

Click below to book a new slot whenever you are ready!
