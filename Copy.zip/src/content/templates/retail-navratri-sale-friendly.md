---
id: retail-navratri-sale-friendly
title: "Shubh Navratri Dandiya Festive Discounts — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: navratri-sale
objective: lead-generation
tone: friendly
language: hinglish
best_time: "09:00-20:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-navratri-sale-friendly.webp"
meta_title: "Shubh Navratri Dandiya Festive Discounts... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping navratri sale. Copy, customize variables, and double your reply conversion rates on ReplyFlow."
preview_snippet: "💃 {{shop_name}} 9 Days Navratri Special Sale! Garba & ethnic shopping par payein UPTO {{discount}}..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant navratri sale touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - shop_name
  - discount
  - date
  - order_link
  - shop_address
tags:
  - navratri-sale
  - dandiya-special
  - garba-collection
buttons:
  - type: url
    text: "💃 Shop Navratri Specials"
variations:
  - title: "Hinglish Version"
    text: "💃 *{{shop_name}}* 9-Days Navratri Special Sale!\n\nGarba & ethnic shopping par payein UPTO {{discount}} OFF!\n\nOffer valid: 1st Navratri se {{date}} tak\nCatalogue: {{order_link}}\nStore Location: {{shop_address}}\n\nShubh Navratri!"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "💃 *{{shop_name}}* 9-दिवसीय नवरात्रि स्पेशल सेल! गरबा और एथनिक शॉपिंग पर पाएं {{discount}} तक की छूट। कैटलॉग: {{order_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "💃 Navratri Special Sale at *{{shop_name}}*! Enjoy UPTO {{discount}} OFF during the 9 days festival. Catalogue: {{order_link}}"
    tone: "professional"
    language: "en"
---
💃 *{{shop_name}}* 9-Days Navratri Special Sale!

Garba & ethnic shopping par payein UPTO {{discount}} OFF!

Offer valid: 1st Navratri se {{date}} tak
Catalogue: {{order_link}}
Store Location: {{shop_address}}

Shubh Navratri!
