---
id: retail-abandoned-cart-reminder-friendly
title: "Cart Recovery Nudge + Special Discount Code — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: abandoned-cart-reminder
objective: retention
tone: friendly
language: hinglish
best_time: "10:00-20:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-abandoned-cart-reminder-friendly.webp"
meta_title: "Cart Recovery Nudge + Special Discount Code... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping abandoned cart reminder. Copy, customize variables, and double your reply conversion rates on R..."
preview_snippet: "Hi {{customer_name}}! 🛒 Aapka cart aapka wait kar raha hai at {{shop_name}} ! Item: {{product_name}}..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant abandoned cart reminder touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - shop_name
  - product_name
  - coupon_code
  - discount
  - order_link
tags:
  - abandoned-cart
  - cart-recovery
  - promo-coupon
buttons:
  - type: url
    text: "🛒 Checkout Cart with {{discount}} OFF"
  - type: reply
    text: "🔄 Change Cart Items"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! 🛒 Aapka cart aapka wait kar raha hai at *{{shop_name}}*!\n\nItem: *{{product_name}}*\n🎁 Exclusive Cart Discount: Use Code *{{coupon_code}}* for {{discount}} OFF!\n\nComplete Cart Now: {{order_link}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! 🛒 आपका कार्ट में छोड़ा गया सामान आपका इंतजार कर रहा है! डिस्काउंट कोड {{coupon_code}} से पाएं {{discount}} की छूट: {{order_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! 🛒 You left {{product_name}} in your cart at *{{shop_name}}*. Complete purchase with promo code *{{coupon_code}}* for {{discount}} OFF: {{order_link}}"
    tone: "professional"
    language: "en"
---
Hi {{customer_name}}! 🛒 Aapka cart aapka wait kar raha hai at *{{shop_name}}*!

Item: *{{product_name}}*
🎁 Exclusive Cart Discount: Use Code *{{coupon_code}}* for {{discount}} OFF!

Complete Cart Now: {{order_link}}
