---
id: retail-beauty-skin-type-recommendation-friendly
title: "Personalized Skincare Routine & Skin-Type Recommendation — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: skin-type-recommendation
objective: lead-generation
tone: friendly
language: hinglish
best_time: "11:00-20:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-beauty-skin-type-recommendation-friendly.webp"
meta_title: "Personalized Skincare Routine & Skin-Type Recommendation | ReplyFlow"
meta_description: "WhatsApp cosmetics template for personalized skincare routines and serum/moisturizer recommendations."
preview_snippet: "Hi {{customer_name}}, {{shop_name}} Beauty Expert se aapke {{skin_type}} skin type ke liye custom skincare routine..."
context_section:
  when_to_use: "Send after customer takes a skin quiz or asks for serum/skincare advice."
  target_audience: "Beauty & cosmetics shoppers."
  customization_tip: "Recommend specific AM/PM skincare products."
variables:
  - customer_name
  - shop_name
  - skin_type
  - recommended_routine
  - discount_code
  - routine_link
tags:
  - skincare-routine
  - beauty-products
  - skin-recommendation
  - cosmetics
buttons:
  - type: url
    text: "✨ Shop Custom Skincare Routine"
  - type: reply
    text: "💬 Chat with Beauty Expert"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! ✨💄\n\n*{{shop_name}}* Beauty Expert team se! Aapke *{{skin_type}}* skin type ke liye custom daily routine:\n\n🌟 Recommended Routine: {{recommended_routine}}\n🎁 Special Routine Discount: Use Code *{{discount_code}}*\n\nShop Routine: {{routine_link}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! *{{shop_name}}* ब्यूटी एक्सपर्ट टीम से। आपकी त्वचा प्रकार (*{{skin_type}}*) के अनुसार खास स्किनकेयर रूटीन: {{routine_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! Personalized skincare recommendation for *{{skin_type}}* skin from *{{shop_name}}*: {{recommended_routine}}. Use Code: *{{discount_code}}*: {{routine_link}}"
    tone: "friendly"
    language: "en"
---
Hi {{customer_name}}! ✨💄

*{{shop_name}}* Beauty Expert team se! Aapke *{{skin_type}}* skin type ke liye custom daily routine:

🌟 Recommended Routine: {{recommended_routine}}
🎁 Special Routine Discount: Use Code *{{discount_code}}*

Shop Routine: {{routine_link}}
