---
id: retail-kirana-fresh-vegetables-update-friendly
title: "Fresh Morning Vegetables Arrival Update — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: fresh-vegetables-update
objective: lead-generation
tone: friendly
language: hinglish
best_time: "07:00-11:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-kirana-fresh-vegetables-update-friendly.webp"
meta_title: "Fresh Morning Vegetables Arrival Update | ReplyFlow"
meta_description: "Morning fresh sabzi update WhatsApp template for local Kirana and vegetable vendors."
preview_snippet: "Good morning {{customer_name}}! Aaj ki taaza sabzi ka stock *{{shop_name}}* par aa gaya hai..."
context_section:
  when_to_use: "Send early morning when fresh vegetable stock arrives from mandai/farm."
  target_audience: "Local neighborhood households."
  customization_tip: "Highlight today's special seasonal veggies."
variables:
  - customer_name
  - shop_name
  - fresh_veggies_list
  - min_delivery_amount
  - shop_link
tags:
  - fresh-vegetables
  - daily-sabzi
  - kirana
  - morning-update
buttons:
  - type: url
    text: "🥬 View Fresh Vegetables List"
  - type: reply
    text: "📝 Send Sabzi List on WhatsApp"
variations:
  - title: "Hinglish Version"
    text: "Good morning {{customer_name}}! 🥬🍅\n\nAaj ki fresh taaza sabzi mandi se *{{shop_name}}* par aa gayi hai!\n\nToday's Special Stock: {{fresh_veggies_list}}\n🚚 Home Delivery Available (Free above ₹{{min_delivery_amount}})\n\nOrder List Send Karein: {{shop_link}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "गुड मॉर्निंग {{customer_name}} जी! 🥬 आज की ताज़ा सब्ज़ी मंडी से आ गयी है: {{fresh_veggies_list}}। होम डिलीवरी के लिए आर्डर भेजें: {{shop_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Good morning {{customer_name}}! Fresh morning farm vegetables have arrived at *{{shop_name}}*: {{fresh_veggies_list}}. Order now for fast delivery: {{shop_link}}"
    tone: "friendly"
    language: "en"
---
Good morning {{customer_name}}! 🥬🍅

Aaj ki fresh taaza sabzi mandi se *{{shop_name}}* par aa gayi hai!

Today's Special Stock: {{fresh_veggies_list}}
🚚 Home Delivery Available (Free above ₹{{min_delivery_amount}})

Order List Send Karein: {{shop_link}}
