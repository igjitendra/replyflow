---
id: retail-operational-emergency-closure-rain-delay-friendly
title: "Heavy Rain / Emergency Delivery Delay & Closure Notice — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: heavy-rain-delivery-delay
objective: support
tone: friendly
language: hinglish
best_time: "08:00-22:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-operational-emergency-closure-rain-delay-friendly.webp"
meta_title: "Heavy Rain / Emergency Delivery Delay & Closure Notice | ReplyFlow"
meta_description: "WhatsApp operational update template for weather emergency, heavy rain delivery delays, and temporary shop closures."
preview_snippet: "Important Update {{customer_name}}: Bhaari baarish / kharab mausam ke kaaran delivery temporarly delay ho sakti hai at {{shop_name}}..."
context_section:
  when_to_use: "Send during monsoon weather emergencies, waterlogging, or unannounced local closures."
  target_audience: "All active order customers."
  customization_tip: "Provide live order tracking link and helpline."
variables:
  - customer_name
  - shop_name
  - delay_reason
  - expected_time
  - tracking_link
tags:
  - emergency-closure
  - rain-delay
  - operational-update
  - delivery-delay
buttons:
  - type: url
    text: "📦 Track Live Delivery Status"
  - type: phone
    text: "📞 Call Helpline"
variations:
  - title: "Hinglish Version"
    text: "Important Update {{customer_name}}! 🌧️⚠️\n\n*{{shop_name}}* se zaruri soochna: Kharab mausam / {{delay_reason}} ke kaaran aapki delivery mein thoda delay ho sakta hai.\n\nRevised Delivery Estimate: *{{expected_time}}*\nSafety priority hai, patience ke liye thank you!\n\nLive Tracking: {{tracking_link}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "महत्वपूर्ण सूचना {{customer_name}} जी! खराब मौसम / {{delay_reason}} के कारण डिलीवरी में कुछ देरी हो सकती है। अनुमानित समय: {{expected_time}}। धैर्य के लिए धन्यवाद!"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Important Update {{customer_name}}! Due to severe weather / {{delay_reason}}, deliveries from *{{shop_name}}* may experience temporary delays. Revised ETA: *{{expected_time}}*. Track status: {{tracking_link}}"
    tone: "friendly"
    language: "en"
---
Important Update {{customer_name}}! 🌧️⚠️

*{{shop_name}}* se zaruri soochna: Kharab mausam / {{delay_reason}} ke kaaran aapki delivery mein thoda delay ho sakta hai.

Revised Delivery Estimate: *{{expected_time}}*
Safety priority hai, patience ke liye thank you!

Live Tracking: {{tracking_link}}
