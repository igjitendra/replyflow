---
id: retail-cart-item-low-stock-warning-friendly
title: "Cart Item Selling Out Fast Warning — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: cart-item-low-stock-warning
objective: retention
tone: friendly
language: hinglish
best_time: "10:00-20:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-cart-item-low-stock-warning-friendly.webp"
meta_title: "Cart Item Selling Out Fast Warning (Whatsapp) | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping cart item low stock warning. Copy, customize variables, and double your reply conversion rates ..."
preview_snippet: "Hi {{customer_name}}! Urgent Alert: Aapke cart ka item {{product_name}} tezi se sell ho raha hai!..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant cart item low stock warning touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - product_name
  - quantity
  - order_link
tags:
  - cart-low-stock
  - selling-fast
  - urgent-checkout
buttons:
  - type: url
    text: "⚡ Lock Item Before Sold Out"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! Urgent Alert: Aapke cart ka item *{{product_name}}* tezi se sell ho raha hai! Bas {{quantity}} units bache hain.\n\nStock khatam hone se pehle checkout karein: {{order_link}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! आपके कार्ट का उत्पाद {{product_name}} तेजी से बिक रहा है! केवल {{quantity}} पीस बचे हैं। तुरंत आर्डर करें: {{order_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! Warning: {{product_name}} in your cart is selling fast! Only {{quantity}} left. Secure now: {{order_link}}"
    tone: "professional"
    language: "en"
---
Hi {{customer_name}}! Urgent Alert: Aapke cart ka item *{{product_name}}* tezi se sell ho raha hai! Bas {{quantity}} units bache hain.

Stock khatam hone se pehle checkout karein: {{order_link}}
