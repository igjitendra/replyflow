---
id: retail-jewellery-daily-gold-rate-friendly
title: "Daily Gold & Silver Rate Update — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: daily-gold-rate
objective: lead-generation
tone: friendly
language: hinglish
best_time: "10:00-14:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-jewellery-daily-gold-rate-friendly.webp"
meta_title: "Daily Gold & Silver Rate Update | ReplyFlow"
meta_description: "WhatsApp template for daily 22K/24K Gold and Silver price updates with making charge discount."
preview_snippet: "Namaste {{customer_name}}! Aaj ka 22K & 24K Gold rate update *{{shop_name}}* par: 24K Gold Rate: ₹{{gold_rate_24k}}/10g..."
context_section:
  when_to_use: "Send daily morning to customers subscribed to gold rates or jewellery buyers."
  target_audience: "Gold investors & jewellery buyers."
  customization_tip: "Highlight making charge discount or zero wastage offer."
variables:
  - customer_name
  - shop_name
  - gold_rate_24k
  - gold_rate_22k
  - silver_rate
  - making_charge_offer
  - shop_link
tags:
  - daily-gold-rate
  - gold-price
  - silver-rate
  - jewellery-shop
buttons:
  - type: url
    text: "✨ View Today's Gold & Silver Rates"
  - type: reply
    text: "👑 Book Jewellery Appointment"
variations:
  - title: "Hinglish Version"
    text: "Namaste {{customer_name}}! 🪙✨\n\nAaj ka *22K & 24K Gold & Silver Rate* update at *{{shop_name}}*:\n\n🥇 24K Gold Rate: *₹{{gold_rate_24k}}/10g*\n🥈 22K Gold Rate: *₹{{gold_rate_22k}}/10g*\n🤍 Silver Rate: *₹{{silver_rate}}/kg*\n\n🎁 Making Charge Special Offer: {{making_charge_offer}}\n\nVisit Showroom or Book Visit: {{shop_link}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! आज का 22K व 24K सोने व चांदी का भाव *{{shop_name}}* पर: 24K गोल्ड: ₹{{gold_rate_24k}}/10g। मेकिंग चार्ज पर छूट: {{making_charge_offer}}। शो रूम पधारें: {{shop_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! Today's 24K & 22K Gold and Silver rates at *{{shop_name}}*: 24K Gold ₹{{gold_rate_24k}}/10g. Special Making Charge Offer: {{making_charge_offer}}. Visit us today: {{shop_link}}"
    tone: "friendly"
    language: "en"
---
Namaste {{customer_name}}! 🪙✨

Aaj ka *22K & 24K Gold & Silver Rate* update at *{{shop_name}}*:

🥇 24K Gold Rate: *₹{{gold_rate_24k}}/10g*
🥈 22K Gold Rate: *₹{{gold_rate_22k}}/10g*
🤍 Silver Rate: *₹{{silver_rate}}/kg*

🎁 Making Charge Special Offer: {{making_charge_offer}}

Visit Showroom or Book Visit: {{shop_link}}
