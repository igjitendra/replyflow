---
id: restaurant-abandoned-cart-incomplete-order-reminder-friendly
title: "Abandoned Cart & Pending Order Recovery Coupon"
industry: restaurant
channel: whatsapp
purpose: abandoned-cart-reminder
objective: lead-generation
tone: friendly
language: hinglish
best_time: "12:00-22:00"
whatsapp_approved: true
thumbnail: "/images/templates/restaurant-abandoned-cart-incomplete-order-reminder-friendly.webp"
meta_title: "Abandoned Cart & Pending Order Recovery Coupon... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Restaurant & Cafe abandoned cart reminder. Copy, customize variables, and double your reply conversion rates on R..."
preview_snippet: "Hey {{customer_name}}! 🛒😋 Hungry? Aapka {{restaurant_name}} cart incomplete reh gaya hai! 📋 Cart Items: {{cart_items}}..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Restaurant & Cafe team needs to execute an instant abandoned cart reminder touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Restaurant & Cafe managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - restaurant_name
  - cart_items
  - discount_code
  - checkout_link
tags:
  - abandoned-cart
  - incomplete-order
  - cart-recovery
  - order-reminder
  - discount-coupon
buttons:
  - type: url
    text: "🛒 Complete Order with 10% OFF"
  - type: reply
    text: "🍲 Clear Cart & Restart"
  - type: phone
    text: "📞 Call Support Desk"
variations:
  - title: "Hinglish Version"
    text: |
      Hey {{customer_name}}! 🛒😋
      
      Hungry? Aapka *{{restaurant_name}}* cart incomplete reh gaya hai!
      
      📋 *Cart Items:* {{cart_items}}
      
      🎁 *Special Cart Recovery Perk:* Use code *{{discount_code}}* for Flat 10% OFF if you complete your order in the next 15 mins!
      
      Complete your order now: {{checkout_link}}
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: |
      हे {{customer_name}}! 🛒😋
      
      भूख लगी है? आपका *{{restaurant_name}}* कार्ट अधूरा रह गया है!
      
      📋 *कार्ट के व्यंजन:* {{cart_items}}
      
      🎁 *विशेष कार्ट छूट:* कूपन *{{discount_code}}* का प्रयोग करें और पाएं 10% की छूट!
      
      अगले 15 मिनट में अपना ऑर्डर पूरा करने के लिए लिंक पर क्लिक करें: {{checkout_link}}
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: |
      Hey {{customer_name}}! 🛒😋
      
      Don't let your delicious meal wait! You left items in your *{{restaurant_name}}* cart:
      
      📋 *Items in Cart:* {{cart_items}}
      
      🎁 *Exclusive Incentive:* Use promo code *{{discount_code}}* to unlock 10% instant savings at checkout.
      
      Tap below to complete your order before items sell out: {{checkout_link}}
    tone: "friendly"
    language: "en"
related:
  - restaurant-order-placement-item-address-confirmation-friendly
  - restaurant-minimum-order-value-delivery-fee-info-friendly
---
Hey {{customer_name}}! 🛒😋

Hungry? Aapka **{{restaurant_name}}** cart incomplete reh gaya hai!

📋 **Cart Items:** {{cart_items}}

🎁 **Special Cart Recovery Perk:** Use code **{{discount_code}}** for Flat 10% OFF if you complete your order in the next 15 mins!

Complete your order now: {{checkout_link}}
