---
id: clinic-inactive-patient-dental-skin-checkup-reminder-friendly
title: "6-Month Routine Health Checkup & Comeback Consultation Voucher — {{clinic_name}}"
industry: clinic
channel: whatsapp
purpose: inactive-patient-reengagement
objective: retention
tone: friendly
language: hinglish
best_time: "10:00-18:00"
whatsapp_approved: true
thumbnail: "/images/templates/clinic-inactive-patient-dental-skin-checkup-reminder-friendly.webp"
meta_title: "6-Month Routine Health Checkup & Comeback Consultation Voucher | ReplyFlow"
meta_description: "Patient re-engagement WhatsApp template for 6-month routine dental, eye, or health checkups."
preview_snippet: "Namaste {{patient_name}} ji, aapki last consultation ko 6 months ho gaye hain. {{clinic_name}} se 50% OFF Checkup Voucher..."
context_section:
  when_to_use: "Send to patients who haven't visited in 6+ months for preventive routine checkup."
  target_audience: "Inactive patients."
  customization_tip: "Offer a discounted checkup package voucher."
variables:
  - patient_name
  - clinic_name
  - doctor_name
  - discount_voucher
  - booking_link
tags:
  - patient-reengagement
  - clinic-comeback
  - routine-checkup
  - preventive-health
buttons:
  - type: url
    text: "🩺 Book Routine Health Checkup"
variations:
  - title: "Hinglish Version"
    text: "Namaste {{patient_name}} ji! 🏥\n\nAapki last visit *Dr. {{doctor_name}}* at *{{clinic_name}}* par 6 mahine pehle hui thi.\n\nRegular routine health checkup zaruri hai! Exclusive Re-engagement Offer: *{{discount_voucher}}*\n\nBook Slot Online: {{booking_link}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{patient_name}} जी! आपके रूटीन स्वास्थ्य चेकअप का समय हो गया है। *{{clinic_name}}* पर 50% छूट कूपन *{{discount_voucher}}* के साथ बुकिंग करें: {{booking_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{patient_name}}! It has been 6 months since your last visit at *{{clinic_name}}*. Schedule your routine health checkup with Dr. {{doctor_name}}: {{booking_link}}"
    tone: "friendly"
    language: "en"
---
Namaste {{patient_name}} ji! 🏥

Aapki last visit *Dr. {{doctor_name}}* at *{{clinic_name}}* par 6 mahine pehle hui thi.

Regular routine health checkup zaruri hai! Exclusive Re-engagement Offer: *{{discount_voucher}}*

Book Slot Online: {{booking_link}}
