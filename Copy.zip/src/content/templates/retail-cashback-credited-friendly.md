---
id: retail-cashback-credited-friendly
title: "Instant Wallet Cashback Credited — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: cashback-credited
objective: retention
tone: friendly
language: hinglish
best_time: "09:00-20:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-cashback-credited-friendly.webp"
meta_title: "Instant Wallet Cashback Credited (Whatsapp) | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping cashback credited. Copy, customize variables, and double your reply conversion rates on ReplyFlow."
preview_snippet: "Hi {{customer_name}}! 💵 Cashback Alert: ₹{{amount}} aapke store wallet me successfully credit ho gaya hai!..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant cashback credited touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - amount
  - order_link
tags:
  - cashback-credited
  - wallet-cashback
  - cash-reward
buttons:
  - type: url
    text: "💵 Use Cashback on Next Order"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! 💵 Cashback Alert: ₹{{amount}} aapke store wallet me successfully credit ho gaya hai!\n\nNext order me use karein: {{order_link}}"
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! 💵 कैश बैक अपडेट: ₹{{amount}} आपके वॉलेट में क्रेडिट हो गया है! अगली खरीदारी में प्रयोग करें: {{order_link}}"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! 💵 Cashback Alert: ₹{{amount}} cashback credited to your wallet. Spend on next order: {{order_link}}"
    tone: "professional"
    language: "en"
---
Hi {{customer_name}}! 💵 Cashback Alert: ₹{{amount}} aapke store wallet me successfully credit ho gaya hai!

Next order me use karein: {{order_link}}
