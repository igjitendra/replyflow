---
id: retail-order-cancellation-request-friendly
title: "Customer Order Cancellation Request Received — {{shop_name}}"
industry: retail
channel: whatsapp
purpose: order-cancellation-request
objective: support
tone: friendly
language: hinglish
best_time: "09:00-21:00"
whatsapp_approved: true
thumbnail: "/images/templates/retail-order-cancellation-request-friendly.webp"
meta_title: "Customer Order Cancellation Request Received... | ReplyFlow"
meta_description: "Get this ready-to-use WHATSAPP template for Retail & Shopping order cancellation request. Copy, customize variables, and double your reply conversion rates o..."
preview_snippet: "Hi {{customer_name}}! ❌ Cancellation Request Received for Order {{order_id}}. Hamari team cancellation reason check karke..."
context_section:
  when_to_use: "Use this WHATSAPP message template whenever your Retail & Shopping team needs to execute an instant order cancellation request touchpoint. It is best triggered immediately following a relevant customer event or as part of a scheduled automated workflow."
  target_audience: "Tailored specifically for business owners, sales reps, and customer support staff in Retail & Shopping managing direct WHATSAPP interactions."
  customization_tip: "Verify all curly brace variables against your CRM contacts database and include a clear 1-click CTA button to maximize immediate engagement."
variables:
  - customer_name
  - order_id
tags:
  - cancellation-request
  - cancel-order
  - customer-cancel
buttons:
  - type: reply
    text: "✅ Confirm Cancellation"
  - type: reply
    text: "🚫 Don't Cancel, Ship It"
variations:
  - title: "Hinglish Version"
    text: "Hi {{customer_name}}! ❌ Cancellation Request Received for Order #{{order_id}}.\n\nHamari team cancellation reason check karke process kar rahi hai."
    tone: "friendly"
    language: "hinglish"
  - title: "Hindi (हिंदी) Version"
    text: "नमस्ते {{customer_name}} जी! ❌ आर्डर #{{order_id}} का कैंसिलेशन अनुरोध प्राप्त हुआ।"
    tone: "friendly"
    language: "hi"
  - title: "English Version"
    text: "Hello {{customer_name}}! ❌ Cancellation request received for Order #{{order_id}}."
    tone: "professional"
    language: "en"
---
Hi {{customer_name}}! ❌ Cancellation Request Received for Order #{{order_id}}.

Hamari team cancellation reason check karke process kar rahi hai.
